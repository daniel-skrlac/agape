import React, { useEffect, useMemo, useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { router, useLocalSearchParams } from "expo-router";

import Screen from "@/components/ui/Screen";
import { Banner } from "@/components/Banner";
import Colors from "@/constants/Colors";

import { useTemplateFolders, useMoveFolder } from "@/app/api/hooks/useDispatchTemplates";
import type { FolderResponseDTO } from "@/app/models/generated";
import { FolderPicker } from "@/components/FolderPicker";
import TemplatesHeader from "../TemplatesHeader";

const MAX_W = 560;

function collectDescendantIds(folders: FolderResponseDTO[], rootId: number): Set<number> {
  const kidsByParent = new Map<number, number[]>();
  for (const f of folders) {
    if (f?.id == null) continue;
    const pid = f.parentId == null ? null : Number(f.parentId);
    if (pid == null) continue;
    const arr = kidsByParent.get(pid) ?? [];
    arr.push(Number(f.id));
    kidsByParent.set(pid, arr);
  }

  const out = new Set<number>();
  const stack = [rootId];
  while (stack.length) {
    const cur = stack.pop()!;
    const kids = kidsByParent.get(cur) ?? [];
    for (const k of kids) {
      if (out.has(k)) continue;
      out.add(k);
      stack.push(k);
    }
  }
  return out;
}

export default function PremjestiMapu() {
  const params = useLocalSearchParams<{ folderId: string }>();
  const folderId = Number(params.folderId);

  const foldersQ = useTemplateFolders();
  const moveM = useMoveFolder();

  const folders = foldersQ.data ?? [];
  const me = useMemo(() => folders.find((f) => Number(f.id) === folderId) ?? null, [folders, folderId]);

  const [targetParentId, setTargetParentId] = useState<number | null>(null);

  useEffect(() => {
    if (!me) return;
    setTargetParentId((me.parentId ?? null) as any);
  }, [me?.id]);

  const excludeIds = useMemo(() => {
    const s = new Set<number>();
    s.add(folderId);
    for (const d of collectDescendantIds(folders, folderId)) s.add(d);
    return s;
  }, [folders, folderId]);

  const err =
    (foldersQ.error as any)?.message ||
    (moveM.error as any)?.message ||
    null;

  return (
    <Screen>
      <TemplatesHeader title="Premjesti mapu" subtitle={`#${folderId}`} fallbackHref="/(tabs)/templates" />

      <View style={s.container}>
        {!!err && <Banner type="error" text={err} />}

        {!me ? (
          <Text style={s.loading}>Učitavam…</Text>
        ) : (
          <>
            <View style={s.card}>
              <Text style={s.title} numberOfLines={2}>{me.name ?? `Mapa #${folderId}`}</Text>
              <Text style={s.sub}>Odaberi novu nad-mapu (ili root).</Text>
            </View>

            <FolderPicker
              title="Odaberi nad-mapu"
              folders={folders}
              selectedId={targetParentId}
              onSelect={setTargetParentId}
              excludeIds={excludeIds}
              allowRoot
              rootLabel="Root (bez nad-mape)"
            />

            <Pressable
              style={[s.primary, moveM.isPending && { opacity: 0.6 }]}
              disabled={moveM.isPending}
              onPress={async () => {
                await moveM.mutateAsync({
                  folderId,
                  payload: { targetParentId: targetParentId as any } as any,
                });
                router.back();
              }}
            >
              <Text style={s.primaryText}>{moveM.isPending ? "Premještam…" : "Premjesti"}</Text>
            </Pressable>

            <Pressable style={s.secondary} onPress={() => router.back()} disabled={moveM.isPending}>
              <Text style={s.secondaryText}>Odustani</Text>
            </Pressable>
          </>
        )}
      </View>
    </Screen>
  );
}

const s = StyleSheet.create({
  container: { padding: 14, gap: 12 },
  loading: { color: Colors.sub, fontWeight: "800", textAlign: "center", marginTop: 20 },
  card: {
    backgroundColor: Colors.bg,
    borderRadius: 18,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.border,
    padding: 14,
    gap: 6,
  },
  title: { fontWeight: "900", color: Colors.text, fontSize: 16 },
  sub: { color: Colors.sub, fontWeight: "800" },

  primary: {
    alignSelf: "center",
    width: "100%",
    maxWidth: MAX_W,
    padding: 12,
    borderRadius: 14,
    backgroundColor: Colors.orange,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 2,
  },
  primaryText: { color: "#fff", fontWeight: "900" },

  secondary: {
    alignSelf: "center",
    width: "100%",
    maxWidth: MAX_W,
    padding: 12,
    borderRadius: 14,
    backgroundColor: "rgba(148,163,184,0.18)",
    alignItems: "center",
    justifyContent: "center",
  },
  secondaryText: { fontWeight: "900", color: Colors.text },
});
