import React, { useEffect, useMemo, useState } from "react";
import { Pressable, StyleSheet, Text, View } from "react-native";
import { router, useLocalSearchParams } from "expo-router";

import Screen from "@/components/ui/Screen";
import { Banner } from "@/components/Banner";
import Colors from "@/constants/Colors";
import TemplatesHeader from "../../TemplatesHeader";

import { useTemplate, useTemplateFolders, useUpdateTemplate } from "@/app/api/hooks/useDispatchTemplates";
import { FolderPicker } from "@/components/FolderPicker";

const MAX_W = 560;

export default function PremjestiPredlozak() {
    const params = useLocalSearchParams<{ id: string }>();
    const templateId = Number(params.id);

    const tQ = useTemplate(templateId);
    const foldersQ = useTemplateFolders();
    const updM = useUpdateTemplate();

    const t = tQ.data;
    const folders = foldersQ.data ?? [];

    const [destFolderId, setDestFolderId] = useState<number | null>(null);

    useEffect(() => {
        if (!t) return;
        setDestFolderId((t.folderId ?? null) as any);
    }, [t?.id]);

    const destName = useMemo(() => {
        if (destFolderId == null) return "Bez mape (root)";
        const f = folders.find((x) => Number(x.id) === Number(destFolderId));
        return f?.name ?? `Mapa #${destFolderId}`;
    }, [destFolderId, folders]);

    const err =
        (tQ.error as any)?.message ||
        (foldersQ.error as any)?.message ||
        (updM.error as any)?.message ||
        null;

    return (
        <Screen>
            <TemplatesHeader title="Premjesti predložak" subtitle={`#${templateId}`} fallbackHref="/(tabs)/templates" />

            <View style={s.container}>
                {!!err && <Banner type="error" text={err} />}

                {!t ? (
                    <Text style={s.loading}>Učitavam…</Text>
                ) : (
                    <>
                        <View style={s.card}>
                            <Text style={s.title} numberOfLines={2}>
                                {t.name ?? `Predložak #${templateId}`}
                            </Text>
                            <Text style={s.sub}>Trenutno: {t.folderId == null ? "Bez mape (root)" : `Mapa #${t.folderId}`}</Text>
                            <Text style={s.sub}>Odredište: {destName}</Text>
                        </View>

                        <FolderPicker
                            title="Odaberi odredišnu mapu"
                            folders={folders}
                            selectedId={destFolderId}
                            onSelect={setDestFolderId}
                            allowRoot
                        />

                        <Pressable
                            style={[s.primary, updM.isPending && { opacity: 0.6 }]}
                            disabled={updM.isPending}
                            onPress={async () => {
                                await updM.mutateAsync({
                                    id: templateId,
                                    payload: { folderId: destFolderId as any } as any,
                                });
                                router.back();
                            }}
                        >
                            <Text style={s.primaryText}>{updM.isPending ? "Spremam…" : "Premjesti"}</Text>
                        </Pressable>

                        <Pressable style={s.secondary} onPress={() => router.back()} disabled={updM.isPending}>
                            <Text style={s.secondaryText}>Odustani</Text>
                        </Pressable>
                    </>
                )}
            </View>
        </Screen>
    );
}

const s = StyleSheet.create({
    container: { padding: 14, gap: 12 },
    loading: { color: Colors.sub, fontWeight: "800", textAlign: "center", marginTop: 20 },
    card: {
        backgroundColor: Colors.bg,
        borderRadius: 18,
        borderWidth: StyleSheet.hairlineWidth,
        borderColor: Colors.border,
        padding: 14,
        gap: 6,
    },
    title: { fontWeight: "900", color: Colors.text, fontSize: 16 },
    sub: { color: Colors.sub, fontWeight: "800" },

    primary: {
        alignSelf: "center",
        width: "100%",
        maxWidth: MAX_W,
        padding: 12,
        borderRadius: 14,
        backgroundColor: Colors.orange,
        alignItems: "center",
        justifyContent: "center",
        marginTop: 2,
    },
    primaryText: { color: "#fff", fontWeight: "900" },

    secondary: {
        alignSelf: "center",
        width: "100%",
        maxWidth: MAX_W,
        padding: 12,
        borderRadius: 14,
        backgroundColor: "rgba(148,163,184,0.18)",
        alignItems: "center",
        justifyContent: "center",
    },
    secondaryText: { fontWeight: "900", color: Colors.text },
});
