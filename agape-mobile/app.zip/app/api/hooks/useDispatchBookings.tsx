// app/api/hooks/useDispatchBookings.ts
import { useInfiniteQuery, useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import type { DispatchResponseDTO } from "@/app/models/generated";
import { DispatchBookingsQuery, fetchDispatchBookingsPage, fetchDispatchById, cancelDispatch } from "./dispatchNotes";


export function useDispatchBookingsInfinite(base: Omit<DispatchBookingsQuery, "page">) {
  return useInfiniteQuery({
    queryKey: ["dispatch-bookings", base],
    initialPageParam: 0,
    queryFn: ({ pageParam }) =>
      fetchDispatchBookingsPage({ ...base, page: pageParam }),
    getNextPageParam: (lastPage) => {
      const total = lastPage?.total ?? 0;
      const size = lastPage?.size ?? base.size;
      const page = lastPage?.page ?? 0;

      const loaded = (page + 1) * size;
      return loaded < total ? page + 1 : undefined;
    },
  });
}

export function useDispatchById(id: number | null) {
  return useQuery({
    queryKey: ["dispatch-note", id],
    queryFn: () => fetchDispatchById(id as number),
    enabled: !!id,
  });
}

export function useCancelDispatch() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: cancelDispatch,
    onSuccess: (updated: DispatchResponseDTO) => {
      // refresh list + detail
      qc.invalidateQueries({ queryKey: ["dispatch-bookings"] });
      qc.invalidateQueries({ queryKey: ["dispatch-note", (updated as any)?.id] });
    },
  });
}
