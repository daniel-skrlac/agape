import React, { useEffect, useMemo, useState } from "react";
import { FlatList, Pressable, StyleSheet, Text, View } from "react-native";
import { useLocalSearchParams } from "expo-router";

import Screen from "@/components/ui/Screen";
import TemplatesHeader from "../../TemplatesHeader";
import Colors from "@/constants/Colors";
import { Banner } from "@/components/Banner";
import { Segmented } from "@/components/Segmented";
import { Sheet } from "@/components/Sheet";
import { SearchPickerSheet } from "@/components/SearchPickerSheet";

import { useCurrentUser } from "@/app/api/hooks/useCurrentUser";

import { partnerService } from "@/app/api/services/partnerService";
import { documentDirectoryService } from "@/app/api/services/documentDirectoryService";
import { itemDirectoryService } from "@/app/api/services/itemDirectoryService";

import { useBookMany, useBookOne, useTemplate } from "@/app/api/hooks/useDispatchTemplates";

import {
  useBookingSession,
  useBookingSessions,
  useCreateBookingSession,
  useDeleteBookingSessionEntry,
  useFinalizeBookingSession,
  useUpsertBookingSessionEntry,
} from "@/app/api/hooks/useBookingSessions";

import type {
  BookingSessionEntryResponseDTO,
  BookingSessionResponseDTO,
  DocumentDescriptorResponseDTO,
  DraftMode,
  ItemDescriptorResponseDTO,
  PartnerResponseDTO,
  TemplateBookExtraDocDTO,
  TemplateBookItemDTO,
  TemplateResponseDTO,
} from "@/app/models/generated";

type BookingView = "DIRECT" | "SESSION";

type ExtraDocDraft = {
  documentId: number;
  note: string;
  items: { itemId: number; quantity: number }[];
};

export default function Otpremi() {
  const params = useLocalSearchParams<{ id?: string }>();
  const templateId = Number(params.id);

  const { session, ready } = useCurrentUser();
  const warehouseId = session?.defaultWarehouseId ?? null;

  const templateQ = useTemplate(templateId);
  const template = templateQ.data as TemplateResponseDTO | undefined;

  const bookOneM = useBookOne();
  const bookManyM = useBookMany();

  const [view, setView] = useState<BookingView>("DIRECT");
  const [draftMode, setDraftMode] = useState<DraftMode>("DRAFT");

  // ----------------------------
  // Partners
  // ----------------------------
  const [partnerPickerOpen, setPartnerPickerOpen] = useState(false);
  const [selectedPartners, setSelectedPartners] = useState<PartnerResponseDTO[]>([]);

  const togglePartner = (p: PartnerResponseDTO) => {
    setSelectedPartners((prev) => {
      const exists = prev.some((x) => x.id === p.id);
      return exists ? prev.filter((x) => x.id !== p.id) : [...prev, p];
    });
  };

  // ----------------------------
  // Extra docs/items
  // ----------------------------
  const [docTypePickerOpen, setDocTypePickerOpen] = useState(false);
  const [docTypes, setDocTypes] = useState<DocumentDescriptorResponseDTO[]>([]);
  const [docTypesErr, setDocTypesErr] = useState<string | null>(null);

  const [extraDocs, setExtraDocs] = useState<ExtraDocDraft[]>([]);
  const [editDocIdx, setEditDocIdx] = useState<number | null>(null);
  const [editDocOpen, setEditDocOpen] = useState(false);

  const [itemPickerOpen, setItemPickerOpen] = useState(false);

  useEffect(() => {
    (async () => {
      if (!ready) return;
      if (warehouseId == null) return;

      try {
        setDocTypesErr(null);

        // adjust documentCode if needed (depends on your backend)
        const list = await documentDirectoryService.listDocTypesByCode({
          warehouseId,
          documentCode: "OTPREMA",
        });

        setDocTypes(list ?? []);
      } catch (e: any) {
        setDocTypesErr(e?.message ?? "Failed to load document types.");
      }
    })();
  }, [ready, warehouseId]);

  const addExtraDoc = (docId: number) => {
    setExtraDocs((prev) => [
      ...prev,
      {
        documentId: docId,
        note: "",
        items: [],
      },
    ]);
  };

  const removeExtraDoc = (idx: number) => {
    setExtraDocs((prev) => prev.filter((_, i) => i !== idx));
  };

  const openEditDoc = (idx: number) => {
    setEditDocIdx(idx);
    setEditDocOpen(true);
  };

  const addItemToDoc = (idx: number, item: ItemDescriptorResponseDTO) => {
    setExtraDocs((prev) =>
      prev.map((d, i) => {
        if (i !== idx) return d;

        const j = d.items.findIndex((x) => x.itemId === item.itemId);
        if (j >= 0) {
          const next = [...d.items];
          next[j] = { ...next[j], quantity: Number(next[j].quantity || 0) + 1 };
          return { ...d, items: next };
        }

        return { ...d, items: [...d.items, { itemId: item.itemId, quantity: 1 }] };
      })
    );
  };

  const setItemQty = (docIdx: number, itemId: number, qty: number) => {
    setExtraDocs((prev) =>
      prev.map((d, i) => {
        if (i !== docIdx) return d;
        const next = d.items
          .map((x) => (x.itemId === itemId ? { ...x, quantity: qty } : x))
          .filter((x) => Number(x.quantity) > 0);
        return { ...d, items: next };
      })
    );
  };

  const extraDocuments: TemplateBookExtraDocDTO[] = useMemo(() => {
    return extraDocs.map((d) => ({
      documentId: d.documentId,
      draft: draftMode === "DRAFT",
      note: d.note ?? "",
      items: d.items.map(
        (it): TemplateBookItemDTO => ({
          itemId: it.itemId,
          quantity: Number(it.quantity) || 0,
        })
      ),
    }));
  }, [extraDocs, draftMode]);

  const docPatches = useMemo(() => [], []);

  // ----------------------------
  // Session mode
  // ----------------------------
  const sessionsQ = useBookingSessions();
  const [sessionPickerOpen, setSessionPickerOpen] = useState(false);
  const [activeSessionId, setActiveSessionId] = useState<number | null>(null);

  const sessionQ = useBookingSession(activeSessionId);
  const activeSession = sessionQ.data as BookingSessionResponseDTO | undefined;

  const createSessionM = useCreateBookingSession();
  const upsertEntryM = useUpsertBookingSessionEntry(activeSessionId ?? 0);
  const finalizeM = useFinalizeBookingSession(activeSessionId ?? 0);
  const deleteEntryM = useDeleteBookingSessionEntry(activeSessionId ?? 0);

  // ----------------------------
  // Results
  // ----------------------------
  const [resultOpen, setResultOpen] = useState(false);
  const [resultText, setResultText] = useState("");

  const err =
    (templateQ.error as any)?.message ||
    (sessionsQ.error as any)?.message ||
    (sessionQ.error as any)?.message ||
    (createSessionM.error as any)?.message ||
    (upsertEntryM.error as any)?.message ||
    (finalizeM.error as any)?.message ||
    (deleteEntryM.error as any)?.message ||
    (bookOneM.error as any)?.message ||
    (bookManyM.error as any)?.message ||
    docTypesErr ||
    null;

  const canDirect =
    ready &&
    !!session?.token &&
    !!template &&
    warehouseId != null &&
    selectedPartners.length > 0 &&
    !bookOneM.isPending &&
    !bookManyM.isPending;

  const canSessionSave =
    ready &&
    !!session?.token &&
    !!template &&
    warehouseId != null &&
    activeSessionId != null &&
    selectedPartners.length > 0 &&
    !upsertEntryM.isPending;

  const canFinalize =
    ready &&
    !!session?.token &&
    activeSessionId != null &&
    !!activeSession &&
    (activeSession.entries?.length ?? 0) > 0 &&
    activeSession.status === "DRAFT" &&
    !finalizeM.isPending;

  // ----------------------------
  // DIRECT submit
  // ----------------------------
  const submitDirect = async () => {
    if (!canDirect) return;

    const base: any = {
      templateId,
      warehouseId,
      documentDate: new Date() as any,
      draftMode,
      docPatches,
      extraDocuments,
    };

    if (selectedPartners.length === 1) {
      const res = await bookOneM.mutateAsync({
        ...base,
        partnerId: selectedPartners[0].id,
      } as any);

      setResultText(`Succeeded: ${res.succeeded}/${res.total} • Failed: ${res.failed}`);
      setResultOpen(true);
      return;
    }

    const res = await bookManyM.mutateAsync({
      ...base,
      partnerIds: selectedPartners.map((x) => x.id),
    } as any);

    setResultText(`Succeeded: ${res.succeeded}/${res.total} • Failed: ${res.failed}`);
    setResultOpen(true);
  };

  // ----------------------------
  // SESSION: save selected partners as entries
  // ----------------------------
  const saveToSession = async () => {
    if (!canSessionSave) return;

    for (const p of selectedPartners) {
      await upsertEntryM.mutateAsync({
        partnerId: p.id,
        templateId,
        draftMode,
        documentDate: null as any,
        docPatches: docPatches as any,
        extraDocuments: extraDocuments as any,
        note: "",
      });
    }

    setResultText(`Saved ${selectedPartners.length} entr${selectedPartners.length === 1 ? "y" : "ies"} to session.`);
    setResultOpen(true);
  };

  const finalizeSession = async () => {
    if (!canFinalize) return;
    const res = await finalizeM.mutateAsync();
    setResultText(`Finalized: ${res.succeeded}/${res.total} • Failed: ${res.failed}`);
    setResultOpen(true);
  };

  // ----------------------------
  // UI
  // ----------------------------
  return (
    <Screen>
      <TemplatesHeader title="Otpremi" subtitle={`Predložak #${templateId}`} fallbackHref="/(tabs)/templates" />

      <View style={s.container}>
        {!!err && <Banner type="error" text={err} />}

        {!ready ? (
          <Text style={s.empty}>Loading…</Text>
        ) : !session?.token ? (
          <Text style={s.empty}>Not logged in.</Text>
        ) : warehouseId == null ? (
          <Text style={s.empty}>Default warehouse is not set.</Text>
        ) : null}

        <Text style={s.label}>View</Text>
        <Segmented<BookingView>
          value={view}
          options={[
            { value: "DIRECT", label: "Direct booking" },
            { value: "SESSION", label: "Session" },
          ]}
          onChange={setView}
        />

        <Text style={s.label}>Draft mode</Text>
        <Segmented<DraftMode>
          value={draftMode}
          options={[
            { value: "DRAFT", label: "Draft" },
            { value: "FINAL", label: "Final" },
          ]}
          onChange={setDraftMode}
        />

        {view === "SESSION" && (
          <View style={s.card}>
            <Text style={s.title}>Session</Text>

            <Text style={s.sub}>
              Active:{" "}
              {activeSessionId == null
                ? "—"
                : activeSession?.title
                  ? `${activeSession.title} (#${activeSessionId})`
                  : `#${activeSessionId}`}
            </Text>

            <View style={{ flexDirection: "row", gap: 10 }}>
              <Pressable style={[s.secondaryBtn, { flex: 1 }]} onPress={() => setSessionPickerOpen(true)}>
                <Text style={s.secondaryText}>Select</Text>
              </Pressable>

              <Pressable
                style={[s.primaryBtn, { flex: 1 }, (createSessionM.isPending || warehouseId == null) && { opacity: 0.6 }]}
                disabled={warehouseId == null || createSessionM.isPending}
                onPress={async () => {
                  if (warehouseId == null) return;
                  const created = await createSessionM.mutateAsync({
                    title: `Today ${new Date().toLocaleDateString()}`,
                    note: "",
                    warehouseId,
                    documentDate: new Date() as any,
                  });
                  setActiveSessionId(created.id);
                }}
              >
                <Text style={s.primaryText}>{createSessionM.isPending ? "Creating…" : "Create"}</Text>
              </Pressable>
            </View>

            <Text style={[s.sub, { marginTop: 8 }]}>
              Status: {activeSession?.status ?? "—"} • Entries: {activeSession?.entries?.length ?? 0}
            </Text>

            <Pressable style={[s.dangerBtn, !canFinalize && { opacity: 0.5 }]} disabled={!canFinalize} onPress={finalizeSession}>
              <Text style={s.dangerText}>{finalizeM.isPending ? "Finalizing…" : "Finalize session"}</Text>
            </Pressable>

            {(activeSession?.entries?.length ?? 0) > 0 && (
              <View style={{ marginTop: 10, gap: 8 }}>
                <Text style={s.title}>Entries</Text>

                {activeSession!.entries.map((e: BookingSessionEntryResponseDTO) => (
                  <View key={String(e.id)} style={s.entryRow}>
                    <View style={{ flex: 1 }}>
                      <Text style={s.title}>Partner #{e.partnerId}</Text>
                      <Text style={s.sub}>
                        Template #{e.templateId} • {e.draftMode}
                      </Text>
                    </View>

                    <Pressable
                      style={[s.dangerBtnSmall, (deleteEntryM.isPending || activeSession?.status !== "DRAFT") && { opacity: 0.6 }]}
                      disabled={deleteEntryM.isPending || activeSession?.status !== "DRAFT"}
                      onPress={async () => {
                        await deleteEntryM.mutateAsync(e.id);
                      }}
                    >
                      <Text style={s.dangerText}>Remove</Text>
                    </Pressable>
                  </View>
                ))}
              </View>
            )}
          </View>
        )}

        <Pressable style={s.primaryBtn} onPress={() => setPartnerPickerOpen(true)}>
          <Text style={s.primaryText}>Select partners</Text>
        </Pressable>

        <Text style={s.label}>Selected partners</Text>
        <FlatList
          data={selectedPartners}
          keyExtractor={(x) => String(x.id)}
          contentContainerStyle={{ gap: 10 }}
          renderItem={({ item }) => (
            <View style={s.partnerRow}>
              <View style={{ flex: 1 }}>
                <Text style={s.title}>{item.name}</Text>
                <Text style={s.sub}>
                  #{item.partnerNumber} • {item.city}
                </Text>
              </View>
              <Pressable style={s.remove} onPress={() => togglePartner(item)}>
                <Text style={s.removeText}>Remove</Text>
              </Pressable>
            </View>
          )}
          ListEmptyComponent={<Text style={s.empty}>No partners selected.</Text>}
        />

        <View style={s.card}>
          <Text style={s.title}>Extra documents</Text>
          <Pressable style={s.secondaryBtn} onPress={() => setDocTypePickerOpen(true)}>
            <Text style={s.secondaryText}>Add document</Text>
          </Pressable>

          {extraDocs.length === 0 ? (
            <Text style={s.empty}>No extra documents.</Text>
          ) : (
            <View style={{ gap: 10 }}>
              {extraDocs.map((d, idx) => (
                <View key={`${d.documentId}-${idx}`} style={s.extraDocRow}>
                  <View style={{ flex: 1 }}>
                    <Text style={s.title}>Doc #{d.documentId}</Text>
                    <Text style={s.sub}>Items: {d.items.length}</Text>
                  </View>
                  <Pressable style={s.secondaryBtnSmall} onPress={() => openEditDoc(idx)}>
                    <Text style={s.secondaryText}>Edit</Text>
                  </Pressable>
                  <Pressable style={s.dangerBtnSmall} onPress={() => removeExtraDoc(idx)}>
                    <Text style={s.dangerText}>Delete</Text>
                  </Pressable>
                </View>
              ))}
            </View>
          )}
        </View>

        {view === "DIRECT" ? (
          <Pressable style={[s.primaryBtn, !canDirect && { opacity: 0.5 }]} disabled={!canDirect} onPress={submitDirect}>
            <Text style={s.primaryText}>{bookOneM.isPending || bookManyM.isPending ? "Booking…" : "Book now"}</Text>
          </Pressable>
        ) : (
          <Pressable style={[s.primaryBtn, !canSessionSave && { opacity: 0.5 }]} disabled={!canSessionSave} onPress={saveToSession}>
            <Text style={s.primaryText}>{upsertEntryM.isPending ? "Saving…" : "Save to session"}</Text>
          </Pressable>
        )}

        {/* Partner picker */}
        <SearchPickerSheet<PartnerResponseDTO>
          visible={partnerPickerOpen}
          title="Select partners"
          onClose={() => setPartnerPickerOpen(false)}
          keyOf={(p) => String(p.id)}
          fetchPage={async ({ page, size, q }) => {
            const res = await partnerService.pagePartners({ page, size, q: q ?? "" });
            return { items: res.items, page: res.page, size: res.size, total: res.total };
          }}
          renderRow={(p) => (
            <Pressable
              style={[s.pickRow, selectedPartners.some((x) => x.id === p.id) ? { borderColor: Colors.orange } : null]}
              onPress={() => togglePartner(p)}
            >
              <Text style={s.pickTitle}>{p.name}</Text>
              <Text style={s.pickSub}>
                #{p.partnerNumber} • {p.city}
              </Text>
            </Pressable>
          )}
        />

        {/* Session picker */}
        <Sheet visible={sessionPickerOpen} title="Select session" onClose={() => setSessionPickerOpen(false)}>
          <View style={{ gap: 10 }}>
            {(sessionsQ.data ?? []).map((sess) => (
              <Pressable
                key={String(sess.id)}
                style={s.pickRow}
                onPress={() => {
                  setActiveSessionId(sess.id);
                  setSessionPickerOpen(false);
                }}
              >
                <Text style={s.pickTitle}>{sess.title || `Session #${sess.id}`}</Text>
                <Text style={s.pickSub}>
                  {sess.status} • entries: {sess.entries?.length ?? 0}
                </Text>
              </Pressable>
            ))}
            {(sessionsQ.data ?? []).length === 0 ? <Text style={s.empty}>No sessions yet.</Text> : null}
          </View>
        </Sheet>

        {/* Doc type picker */}
        <Sheet visible={docTypePickerOpen} title="Select document" onClose={() => setDocTypePickerOpen(false)}>
          <View style={{ gap: 10 }}>
            {docTypes.map((dt) => (
              <Pressable
                key={String(dt.documentId)}
                style={s.pickRow}
                onPress={() => {
                  addExtraDoc(dt.documentId);
                  setDocTypePickerOpen(false);
                }}
              >
                <Text style={s.pickTitle}>{dt.displayName}</Text>
                <Text style={s.pickSub}>
                  #{dt.documentId} • {dt.documentCode}
                </Text>
              </Pressable>
            ))}
            {docTypes.length === 0 ? <Text style={s.empty}>No document types.</Text> : null}
          </View>
        </Sheet>

        {/* Edit doc */}
        <Sheet
          visible={editDocOpen}
          title={editDocIdx == null ? "Edit document" : `Edit doc #${extraDocs[editDocIdx]?.documentId ?? ""}`}
          onClose={() => setEditDocOpen(false)}
        >
          {editDocIdx == null ? (
            <Text style={s.empty}>—</Text>
          ) : (
            <View style={{ gap: 10 }}>
              <Pressable style={s.secondaryBtn} onPress={() => setItemPickerOpen(true)}>
                <Text style={s.secondaryText}>Add item</Text>
              </Pressable>

              {extraDocs[editDocIdx]?.items?.length ? (
                <View style={{ gap: 10 }}>
                  {extraDocs[editDocIdx].items.map((it) => (
                    <View key={String(it.itemId)} style={s.extraItemRow}>
                      <Text style={s.title}>Item #{it.itemId}</Text>

                      <View style={{ flexDirection: "row", gap: 10, alignItems: "center" }}>
                        <Pressable style={s.qtyBtn} onPress={() => setItemQty(editDocIdx, it.itemId, Math.max(0, it.quantity - 1))}>
                          <Text style={s.qtyBtnText}>-</Text>
                        </Pressable>
                        <Text style={s.sub}>{it.quantity}</Text>
                        <Pressable style={s.qtyBtn} onPress={() => setItemQty(editDocIdx, it.itemId, it.quantity + 1)}>
                          <Text style={s.qtyBtnText}>+</Text>
                        </Pressable>
                      </View>
                    </View>
                  ))}
                </View>
              ) : (
                <Text style={s.empty}>No items in this document.</Text>
              )}

              <Pressable style={s.primaryBtn} onPress={() => setEditDocOpen(false)}>
                <Text style={s.primaryText}>Done</Text>
              </Pressable>
            </View>
          )}
        </Sheet>

        {/* Item picker */}
        <SearchPickerSheet<ItemDescriptorResponseDTO>
          visible={itemPickerOpen}
          title="Select item"
          onClose={() => setItemPickerOpen(false)}
          keyOf={(x) => String(x.itemId)}
          fetchPage={async ({ page, size, q }) => {
            if (warehouseId == null) return { items: [], page, size, total: 0 };
            const res = await itemDirectoryService.pageItems({ warehouseId, page, size, q: q ?? "" });
            return { items: res.items, page: res.page, size: res.size, total: res.total };
          }}
          renderRow={(it) => (
            <Pressable
              style={s.pickRow}
              onPress={() => {
                if (editDocIdx == null) return;
                addItemToDoc(editDocIdx, it);
              }}
            >
              <Text style={s.pickTitle}>{it.name}</Text>
              <Text style={s.pickSub}>
                {it.code} • {it.unit}
              </Text>
            </Pressable>
          )}
        />

        {/* Result */}
        <Sheet visible={resultOpen} title="Result" onClose={() => setResultOpen(false)}>
          <Text style={{ fontWeight: "900", color: Colors.text }}>{resultText}</Text>
          <Pressable style={s.primaryBtn} onPress={() => setResultOpen(false)}>
            <Text style={s.primaryText}>OK</Text>
          </Pressable>
        </Sheet>
      </View>
    </Screen>
  );
}

const s = StyleSheet.create({
  container: { padding: 14, gap: 12 },
  label: { fontWeight: "900", color: Colors.text },

  title: { fontWeight: "900", color: Colors.text },
  sub: { color: Colors.sub, fontWeight: "700" },

  card: {
    backgroundColor: Colors.bg,
    borderRadius: 18,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.border,
    padding: 14,
    gap: 10,
  },

  primaryBtn: { padding: 12, borderRadius: 14, backgroundColor: Colors.orange, alignItems: "center" },
  primaryText: { color: "#fff", fontWeight: "900" },

  secondaryBtn: { padding: 12, borderRadius: 14, backgroundColor: "rgba(148,163,184,0.18)", alignItems: "center" },
  secondaryBtnSmall: { paddingHorizontal: 12, paddingVertical: 10, borderRadius: 14, backgroundColor: "rgba(148,163,184,0.18)" },
  secondaryText: { fontWeight: "900", color: Colors.text },

  dangerBtn: { padding: 12, borderRadius: 14, backgroundColor: Colors.dangerBg, alignItems: "center" },
  dangerBtnSmall: { paddingHorizontal: 12, paddingVertical: 10, borderRadius: 14, backgroundColor: Colors.dangerBg },
  dangerText: { fontWeight: "900", color: Colors.dangerText },

  partnerRow: {
    backgroundColor: Colors.bg,
    borderRadius: 18,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.border,
    padding: 14,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },

  remove: { paddingHorizontal: 12, paddingVertical: 10, borderRadius: 14, backgroundColor: Colors.dangerBg },
  removeText: { fontWeight: "900", color: Colors.dangerText },

  empty: { textAlign: "center", color: Colors.sub, fontWeight: "800", marginTop: 8 },

  pickRow: { padding: 12, borderRadius: 14, borderWidth: StyleSheet.hairlineWidth, borderColor: Colors.border, backgroundColor: Colors.bg, gap: 4 },
  pickTitle: { fontWeight: "900", color: Colors.text },
  pickSub: { color: Colors.sub, fontWeight: "700" },

  extraDocRow: {
    padding: 12,
    borderRadius: 14,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.border,
    backgroundColor: Colors.bg,
    flexDirection: "row",
    gap: 10,
    alignItems: "center",
  },

  extraItemRow: {
    padding: 12,
    borderRadius: 14,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.border,
    backgroundColor: Colors.bg,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  entryRow: {
    padding: 12,
    borderRadius: 14,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.border,
    backgroundColor: Colors.bg,
    flexDirection: "row",
    gap: 10,
    alignItems: "center",
  },

  qtyBtn: { paddingHorizontal: 12, paddingVertical: 8, borderRadius: 12, backgroundColor: "rgba(148,163,184,0.18)" },
  qtyBtnText: { fontWeight: "900", color: Colors.text },
});
