import React, { useMemo, useState } from "react";
import {
  FlatList,
  Modal,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from "react-native";
import FontAwesome from "@expo/vector-icons/FontAwesome";
import { router, useLocalSearchParams } from "expo-router";

import Screen from "@/components/ui/Screen";
import { documentDirectoryService } from "@/app/api/services/documentDirectoryService";
import type {
  DocumentDescriptorResponseDTO,
  TemplateDocResponseDTO,
  TemplateItemUpsertRequestDTO,
} from "@/app/models/generated";
import {
  useTemplate,
  useUpsertDoc,
  useReplaceItems,
  useDeleteDoc,
} from "@/app/api/hooks/useDispatchTemplates";
import { useCurrentUser } from "@/app/api/hooks/useCurrentUser";
import { Banner } from "@/components/Banner";
import { SearchPickerSheet } from "@/components/SearchPickerSheet";
import { CenterConfirmSheet } from "@/components/CenterConfirmSheet";
import Colors from "@/constants/Colors";
import TemplatesHeader from "../../TemplatesHeader";

const MAX_W = 520;

// ------------------------------
// Centered modal (not bottom sheet)
// ------------------------------
function CenterModal(props: {
  visible: boolean;
  title: string;
  onClose: () => void;
  children: React.ReactNode;
  disableClose?: boolean;
}) {
  const { visible, title, onClose, children, disableClose } = props;

  return (
    <Modal visible={visible} transparent animationType="fade" onRequestClose={onClose}>
      <View style={s.modalOverlay}>
        <Pressable
          style={StyleSheet.absoluteFill}
          onPress={() => {
            if (disableClose) return;
            onClose();
          }}
        />
        <View style={s.modalCard}>
          <Text style={s.modalTitle}>{title}</Text>
          <ScrollView
            style={{ width: "100%" }}
            contentContainerStyle={s.modalBody}
            keyboardShouldPersistTaps="handled"
          >
            {children}
          </ScrollView>
        </View>
      </View>
    </Modal>
  );
}

export default function Dokumenti() {
  const params = useLocalSearchParams<{ id: string }>();
  const templateId = Number(params.id);

  const { session, ready } = useCurrentUser();
  const warehouseId = session?.defaultWarehouseId ?? null;

  const DOC_CODE = "OTPREMNICA";

  // ✅ hard block if main warehouse is missing
  if (ready && !warehouseId) {
    return (
      <Screen>
        <TemplatesHeader title="Dokumenti" subtitle={`Predložak #${templateId}`} fallbackHref="/(tabs)/templates" />
        <View style={s.container}>
          <Banner
            type="error"
            text="Nema odabranog glavnog skladišta. U Postavkama prvo odaberi glavno skladište da bi mogao koristiti Predloške."
          />

          <Pressable style={s.primary} onPress={() => router.push("/(tabs)/settings")}>
            <FontAwesome name="cog" size={14} color="#fff" />
            <Text style={s.primaryText}>Otvori postavke</Text>
          </Pressable>

          <Pressable style={s.btnWide} onPress={() => router.back()}>
            <Text style={s.btnText}>Natrag</Text>
          </Pressable>
        </View>
      </Screen>
    );
  }

  const tQ = useTemplate(templateId);
  const upsertDocM = useUpsertDoc();
  const replaceItemsM = useReplaceItems();
  const deleteDocM = useDeleteDoc();

  const t = tQ.data;

  // show only OTPREMNICA docs if code exists on object
  const docs = useMemo(() => {
    const all = t?.documents ?? [];
    return all.filter((d: any) => {
      const code = (d?.documentCode ?? d?.code ?? "").toString().toUpperCase();
      if (!code) return true;
      return code === DOC_CODE;
    });
  }, [t?.documents]);

  // picker
  const [docPickerOpen, setDocPickerOpen] = useState(false);

  // EDIT DOC (center modal)
  const [editDocOpen, setEditDocOpen] = useState(false);
  const [editDoc, setEditDoc] = useState<TemplateDocResponseDTO | null>(null);
  const [draft, setDraft] = useState(true);
  const [note, setNote] = useState("");

  // ITEMS (center modal)
  const [itemsOpen, setItemsOpen] = useState(false);
  const [itemsDoc, setItemsDoc] = useState<TemplateDocResponseDTO | null>(null);

  // ADD ITEM (center modal)
  const [addItemOpen, setAddItemOpen] = useState(false);
  const [itemId, setItemId] = useState("");
  const [qty, setQty] = useState("");

  // DELETE CONFIRM (your UI)
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleteDoc, setDeleteDoc] = useState<TemplateDocResponseDTO | null>(null);

  const err =
    (tQ.error as any)?.message ||
    (upsertDocM.error as any)?.message ||
    (replaceItemsM.error as any)?.message ||
    (deleteDocM.error as any)?.message ||
    null;

  const openEdit = (d: TemplateDocResponseDTO) => {
    setEditDoc(d);
    setDraft(!!d.draft);
    setNote(d.defaultNote ?? "");
    setEditDocOpen(true);
  };

  const openItems = (d: TemplateDocResponseDTO) => {
    // clone so changes are local until save
    const cloned = {
      ...d,
      items: (d.items ?? []).map((x: any) => ({ ...x })),
    } as any;
    setItemsDoc(cloned);
    setItemsOpen(true);
  };

  const openDelete = (d: TemplateDocResponseDTO) => {
    setDeleteDoc(d);
    setDeleteOpen(true);
  };

  const saveDocMeta = async () => {
    if (!editDoc) return;

    await upsertDocM.mutateAsync({
      templateId,
      payload: {
        documentId: editDoc.documentId,
        sortOrder: editDoc.sortOrder ?? 1,
        draft,
        defaultNote: note,
      } as any,
    });

    setEditDocOpen(false);
    setEditDoc(null);
    tQ.refetch();
  };

  const addItem = () => {
    if (!itemsDoc) return;

    const id = Number(itemId);
    const qn = Number(qty);
    if (!Number.isFinite(id) || id <= 0) return;
    if (!Number.isFinite(qn) || qn <= 0) return;

    const current = (itemsDoc.items ?? []).map((i: any) => ({
      itemId: i.itemId,
      quantity: i.quantity,
      sortOrder: i.sortOrder,
    }));

    current.push({ itemId: id, quantity: qn as any, sortOrder: current.length + 1 });

    setItemsDoc({ ...itemsDoc, items: current as any });
    setItemId("");
    setQty("");
    setAddItemOpen(false);
  };

  const removeItem = (idx: number) => {
    if (!itemsDoc) return;
    const arr = [...(itemsDoc.items ?? [])];
    arr.splice(idx, 1);
    const fixed = arr.map((x: any, i: number) => ({ ...x, sortOrder: i + 1 }));
    setItemsDoc({ ...itemsDoc, items: fixed as any });
  };

  const saveItems = async () => {
    if (!itemsDoc) return;

    const payload: TemplateItemUpsertRequestDTO[] = (itemsDoc.items ?? []).map((x: any, i: number) => ({
      itemId: x.itemId,
      quantity: x.quantity,
      sortOrder: i + 1,
    })) as any;

    await replaceItemsM.mutateAsync({
      templateId,
      docId: itemsDoc.id,
      items: payload,
    });

    setItemsOpen(false);
    setItemsDoc(null);
    tQ.refetch();
  };

  const confirmDelete = async () => {
    if (!deleteDoc) return;

    await deleteDocM.mutateAsync({ templateId, templateDocId: deleteDoc.id } as any);
    setDeleteOpen(false);
    setDeleteDoc(null);
    tQ.refetch();
  };

  // SearchPickerSheet expects paging; backend returns full list — local paging
  const fetchDocTypesPage = async ({ page, size, q }: { page: number; size: number; q?: string }) => {
    if (!warehouseId) return { items: [] as DocumentDescriptorResponseDTO[], page, size, total: 0 };

    const all = await documentDirectoryService.listDocTypesByCode(
      { warehouseId, documentCode: DOC_CODE, q: q ?? undefined },
      undefined
    );

    const needle = (q ?? "").trim().toLowerCase();

    const filtered = !needle
      ? all
      : all.filter((d) => {
          const a = (d.displayName ?? "").toLowerCase();
          const b = (d.documentCode ?? "").toLowerCase();
          const c = String(d.documentId ?? "");
          return a.includes(needle) || b.includes(needle) || c.includes(needle);
        });

    filtered.sort((a, b) => (a.displayName ?? "").localeCompare(b.displayName ?? "", "hr", { sensitivity: "base" }));

    const start = page * size;
    const end = start + size;

    return { items: filtered.slice(start, end), page, size, total: filtered.length };
  };

  return (
    <Screen>
      <TemplatesHeader title="Dokumenti" subtitle={`Predložak #${templateId}`} fallbackHref="/(tabs)/templates" />

      <View style={s.container}>
        {!!err && <Banner type="error" text={err} />}

        {!t ? (
          <Text style={s.loading}>Učitavam…</Text>
        ) : (
          <>
            <Pressable style={s.primary} onPress={() => setDocPickerOpen(true)}>
              <FontAwesome name="plus" size={14} color="#fff" />
              <Text style={s.primaryText}>Dodaj dokument</Text>
            </Pressable>

            <FlatList
              data={docs}
              keyExtractor={(d) => String(d.id)}
              contentContainerStyle={{ gap: 10, paddingBottom: 24 }}
              renderItem={({ item }) => (
                <View style={s.card}>
                  <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
                    <Text style={s.title}>Dokument #{item.documentId}</Text>
                    <Text style={s.sub}>{item.draft ? "Skica" : "Konačno"}</Text>
                  </View>

                  {!!item.defaultNote && (
                    <Text style={s.desc} numberOfLines={2}>
                      {item.defaultNote}
                    </Text>
                  )}

                  <Text style={s.desc}>Stavki: {item.items?.length ?? 0}</Text>

                  <View style={s.actionsRow}>
                    <Pressable style={s.actionBtn} onPress={() => openEdit(item)}>
                      <Text style={s.actionText}>Uredi</Text>
                    </Pressable>

                    <Pressable style={s.actionBtn} onPress={() => openItems(item)}>
                      <Text style={s.actionText}>Stavke</Text>
                    </Pressable>

                    <Pressable
                      style={[s.actionBtn, { backgroundColor: Colors.dangerBg }]}
                      onPress={() => openDelete(item)}
                      disabled={deleteDocM.isPending}
                    >
                      <Text style={[s.actionText, { color: Colors.dangerText }]}>
                        {deleteDocM.isPending ? "…" : "Obriši"}
                      </Text>
                    </Pressable>
                  </View>
                </View>
              )}
              ListEmptyComponent={<Text style={s.empty}>Nema dokumenata u predlošku.</Text>}
            />

            {/* PICK DOCUMENT TYPE */}
            <SearchPickerSheet<DocumentDescriptorResponseDTO>
              visible={docPickerOpen}
              title="Odaberi dokument"
              onClose={() => setDocPickerOpen(false)}
              keyOf={(x) => String(x.documentId)}
              fetchPage={fetchDocTypesPage}
              renderRow={(d, close) => (
                <Pressable
                  style={s.pickRow}
                  onPress={async () => {
                    const sortOrder = docs.length + 1;

                    await upsertDocM.mutateAsync({
                      templateId,
                      payload: {
                        documentId: d.documentId,
                        sortOrder,
                        draft: true,
                        defaultNote: "",
                      } as any,
                    });

                    close();
                    tQ.refetch();
                  }}
                >
                  <Text style={s.pickTitle}>{d.displayName}</Text>
                  <Text style={s.pickSub}>
                    Šifra: {d.documentCode} • ID: {d.documentId} • Skladište: {warehouseId}
                  </Text>
                </Pressable>
              )}
            />

            {/* EDIT DOC (centered modal) */}
            <CenterModal
              visible={editDocOpen}
              title="Uredi dokument"
              disableClose={upsertDocM.isPending}
              onClose={() => {
                if (upsertDocM.isPending) return;
                setEditDocOpen(false);
                setEditDoc(null);
              }}
            >
              <Pressable style={s.toggle} onPress={() => setDraft((v) => !v)}>
                <Text style={s.toggleText}>{draft ? "Skica: DA" : "Skica: NE"}</Text>
              </Pressable>

              <TextInput
                value={note}
                onChangeText={setNote}
                placeholder="Zadana napomena (opcionalno)"
                style={s.input}
              />

              <Pressable
                style={[s.primary, upsertDocM.isPending && { opacity: 0.6 }]}
                disabled={upsertDocM.isPending}
                onPress={saveDocMeta}
              >
                <Text style={s.primaryText}>Spremi</Text>
              </Pressable>

              <Pressable
                style={s.btnWide}
                disabled={upsertDocM.isPending}
                onPress={() => {
                  setEditDocOpen(false);
                  setEditDoc(null);
                }}
              >
                <Text style={s.btnText}>Zatvori</Text>
              </Pressable>
            </CenterModal>

            {/* ITEMS (centered modal) */}
            <CenterModal
              visible={itemsOpen}
              title="Stavke dokumenta"
              disableClose={replaceItemsM.isPending}
              onClose={() => {
                if (replaceItemsM.isPending) return;
                setItemsOpen(false);
                setItemsDoc(null);
              }}
            >
              {!itemsDoc ? null : (
                <>
                  <Text style={s.sheetTitle}>Dokument #{itemsDoc.documentId}</Text>

                  <Pressable style={s.btnWide} onPress={() => setAddItemOpen(true)}>
                    <Text style={s.btnText}>Dodaj stavku</Text>
                  </Pressable>

                  <View style={{ gap: 10, width: "100%" }}>
                    {(itemsDoc.items ?? []).map((it: any, idx: number) => (
                      <View key={`${it.itemId}-${idx}`} style={s.itemRow}>
                        <View style={{ flex: 1 }}>
                          <Text style={s.itemTitle}>Artikl ID: {it.itemId}</Text>
                          <Text style={s.itemSub}>Količina: {it.quantity}</Text>
                        </View>

                        <Pressable
                          style={[s.smallDangerBtn, replaceItemsM.isPending && { opacity: 0.6 }]}
                          disabled={replaceItemsM.isPending}
                          onPress={() => removeItem(idx)}
                        >
                          <Text style={s.smallDangerText}>Ukloni</Text>
                        </Pressable>
                      </View>
                    ))}
                  </View>

                  <Pressable
                    style={[s.primary, replaceItemsM.isPending && { opacity: 0.6 }]}
                    disabled={replaceItemsM.isPending}
                    onPress={saveItems}
                  >
                    <Text style={s.primaryText}>Spremi stavke</Text>
                  </Pressable>

                  <Text style={s.hint}>
                    Napomena: za artikle trenutno koristi ID jer nemamo endpoint za pretraživanje artikala.
                  </Text>

                  <Pressable
                    style={s.btnWide}
                    disabled={replaceItemsM.isPending}
                    onPress={() => {
                      setItemsOpen(false);
                      setItemsDoc(null);
                    }}
                  >
                    <Text style={s.btnText}>Zatvori</Text>
                  </Pressable>
                </>
              )}
            </CenterModal>

            {/* ADD ITEM (centered modal) */}
            <CenterModal
              visible={addItemOpen}
              title="Dodaj stavku"
              onClose={() => {
                setAddItemOpen(false);
                setItemId("");
                setQty("");
              }}
            >
              <TextInput
                value={itemId}
                onChangeText={setItemId}
                placeholder="Artikl ID"
                keyboardType="number-pad"
                style={s.input}
              />
              <TextInput
                value={qty}
                onChangeText={setQty}
                placeholder="Količina"
                keyboardType="decimal-pad"
                style={s.input}
              />

              <Pressable style={s.primary} onPress={addItem}>
                <Text style={s.primaryText}>Dodaj</Text>
              </Pressable>

              <Pressable
                style={s.btnWide}
                onPress={() => {
                  setAddItemOpen(false);
                  setItemId("");
                  setQty("");
                }}
              >
                <Text style={s.btnText}>Zatvori</Text>
              </Pressable>
            </CenterModal>

            {/* CONFIRM DELETE (your UI component) */}
            <CenterConfirmSheet
              visible={deleteOpen}
              title="Obrisati dokument?"
              description={
                deleteDoc
                  ? `Dokument #${deleteDoc.documentId}\nObrisat će se i sve stavke dokumenta iz predloška.`
                  : ""
              }
              confirmText="Obriši"
              danger
              loading={deleteDocM.isPending}
              onClose={() => {
                if (deleteDocM.isPending) return;
                setDeleteOpen(false);
                setDeleteDoc(null);
              }}
              onConfirm={confirmDelete}
            />
          </>
        )}
      </View>
    </Screen>
  );
}

const s = StyleSheet.create({
  container: { padding: 14, gap: 12 },
  loading: { color: Colors.sub, fontWeight: "800", textAlign: "center", marginTop: 20 },

  primary: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    padding: 12,
    borderRadius: 14,
    backgroundColor: Colors.orange,
    alignSelf: "center",
    width: "100%",
    maxWidth: MAX_W,
  },
  primaryText: { color: "#fff", fontWeight: "900" },

  card: {
    backgroundColor: Colors.bg,
    borderRadius: 18,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.border,
    padding: 14,
    gap: 8,
  },
  title: { fontWeight: "900", color: Colors.text, fontSize: 15 },
  sub: { color: Colors.sub, fontWeight: "800" },
  desc: { color: Colors.sub, fontWeight: "700" },

  actionsRow: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: 10,
    marginTop: 4,
    flexWrap: "wrap",
  },
  actionBtn: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 14,
    backgroundColor: "rgba(148,163,184,0.18)",
    alignItems: "center",
    justifyContent: "center",
  },
  actionText: { fontWeight: "900", color: Colors.text },

  btnWide: {
    alignSelf: "center",
    width: "100%",
    maxWidth: MAX_W,
    padding: 12,
    borderRadius: 14,
    backgroundColor: "rgba(148,163,184,0.18)",
    alignItems: "center",
    justifyContent: "center",
  },
  btnText: { fontWeight: "900", color: Colors.text },

  pickRow: {
    padding: 12,
    borderRadius: 14,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.border,
    backgroundColor: Colors.bg,
    gap: 4,
  },
  pickTitle: { fontWeight: "900", color: Colors.text },
  pickSub: { color: Colors.sub, fontWeight: "700" },

  toggle: {
    alignSelf: "center",
    width: "100%",
    maxWidth: MAX_W,
    padding: 12,
    borderRadius: 14,
    backgroundColor: "rgba(148,163,184,0.18)",
    alignItems: "center",
    justifyContent: "center",
  },
  toggleText: { fontWeight: "900", color: Colors.text },

  input: {
    alignSelf: "center",
    width: "100%",
    maxWidth: MAX_W,
    backgroundColor: Colors.bg,
    borderRadius: 14,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.border,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontWeight: "800",
    color: Colors.text,
  },

  sheetTitle: { fontWeight: "900", color: Colors.text, textAlign: "center" },

  itemRow: {
    alignSelf: "center",
    width: "100%",
    maxWidth: MAX_W,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    padding: 12,
    borderRadius: 14,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.border,
    backgroundColor: Colors.bg,
  },
  itemTitle: { fontWeight: "900", color: Colors.text },
  itemSub: { color: Colors.sub, fontWeight: "700" },

  smallDangerBtn: {
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 12,
    backgroundColor: Colors.dangerBg,
    alignItems: "center",
    justifyContent: "center",
  },
  smallDangerText: { fontWeight: "900", color: Colors.dangerText },

  hint: { color: Colors.sub, fontWeight: "700", marginTop: 6, textAlign: "center" },
  empty: { textAlign: "center", color: Colors.sub, fontWeight: "800", marginTop: 18 },

  // modal
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.45)",
    alignItems: "center",
    justifyContent: "center",
    padding: 16,
  },
  modalCard: {
    width: "100%",
    maxWidth: MAX_W,
    borderRadius: 18,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.border,
    backgroundColor: Colors.bg,
    padding: 14,
    maxHeight: "80%",
  },
  modalTitle: {
    fontWeight: "900",
    color: Colors.text,
    fontSize: 16,
    textAlign: "center",
    marginBottom: 10,
  },
  modalBody: {
    gap: 12,
    alignItems: "center",
    justifyContent: "center",
    paddingBottom: 6,
  },
});
