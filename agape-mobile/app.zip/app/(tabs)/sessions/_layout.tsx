import React from "react";
import { Stack } from "expo-router";
import RequireMainWarehouse from "../templates/RequireMainWarehouse";
import AuthBackground from "@/components/auth/AuthBackground";

export default function SessionsLayout() {
    return (
        <AuthBackground>
            <RequireMainWarehouse>
                <Stack screenOptions={{ headerShown: false }}>
                    <Stack.Screen name="index" />
                    <Stack.Screen name="[id]" />
                </Stack>
            </RequireMainWarehouse>
        </AuthBackground>
    );
}
