import React, { useEffect, useMemo, useRef, useState } from "react";
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import FontAwesome from "@expo/vector-icons/FontAwesome";
import { useLocalSearchParams, router } from "expo-router";

import Screen from "@/components/ui/Screen";
import Colors from "@/constants/Colors";
import { Banner } from "@/components/Banner";
import TemplatesHeader from "@/app/(tabs)/templates/TemplatesHeader";

import type { BookingSessionResponseDTO, ItemDescriptorResponseDTO, TemplateBookItemDTO } from "@/app/models/generated";

import { itemDirectoryService } from "@/app/api/services/itemDirectoryService";
import { useBookingSession } from "@/app/api/hooks/useBookingSessions";

import { QtyMap, useEntryDraft, patchDraft } from "../_entryDraftStore";

const MAX_W = 560;
const PAGE_SIZE = 10;
const PLACEHOLDER = "rgba(148,163,184,0.85)";

function upsertQty(qty: QtyMap, itemId: number, delta: number) {
  const k = String(itemId);
  const cur = Number(qty[k] ?? 0);
  const next = cur + delta;
  if (next <= 0) {
    const { [k]: _, ...rest } = qty;
    return rest;
  }
  return { ...qty, [k]: next };
}

function qtyToItems(qty: QtyMap): TemplateBookItemDTO[] {
  return Object.entries(qty ?? {})
    .map(([k, v]) => ({ itemId: Number(k), quantity: Number(v) }))
    .filter((x) => x.itemId && x.quantity > 0)
    .sort((a, b) => Number(a.itemId) - Number(b.itemId));
}

export default function SessionEntryStandaloneItems() {
  const params = useLocalSearchParams<{ id: string; partnerId: string }>();
  const sessionId = Number(params.id);
  const partnerId = Number(params.partnerId);

  const sQ = useBookingSession(sessionId);
  const session = sQ.data as BookingSessionResponseDTO | undefined;
  const warehouseId = Number((session as any)?.warehouseId ?? 0) || null;

  const draft = useEntryDraft(sessionId, partnerId);

  const [tab, setTab] = useState<"results" | "added">("results");
  const [searchQ, setSearchQ] = useState("");
  const [debouncedQ, setDebouncedQ] = useState("");
  const [page, setPage] = useState(0);

  useEffect(() => {
    const t = setTimeout(() => setDebouncedQ(searchQ.trim()), 250);
    return () => clearTimeout(t);
  }, [searchQ]);

  useEffect(() => setPage(0), [debouncedQ]);

  const [qtyDraft, setQtyDraft] = useState<QtyMap>({});

  // init from draft.standaloneQty
  useEffect(() => {
    setQtyDraft({ ...(draft?.standaloneQty ?? {}) });
  }, [draft?.standaloneQty]);

  const err = (sQ.error as any)?.message || null;

  const itemsQ = useMemo(() => {
    // lightweight "manual query" state; we will fetch on demand in effect
    return { items: [] as ItemDescriptorResponseDTO[], total: 0, loading: false, error: null as any };
  }, []);

  const [rows, setRows] = useState<ItemDescriptorResponseDTO[]>([]);
  const [total, setTotal] = useState<number>(0);
  const [loading, setLoading] = useState<boolean>(false);
  const [loadErr, setLoadErr] = useState<string | null>(null);

  useEffect(() => {
    let alive = true;
    (async () => {
      if (!warehouseId) return;
      setLoading(true);
      setLoadErr(null);
      try {
        const res = await itemDirectoryService.pageItems({
          warehouseId: Number(warehouseId),
          page,
          size: PAGE_SIZE,
          q: debouncedQ || "",
        });

        if (!alive) return;
        setRows((res as any).items ?? []);
        setTotal(Number((res as any).total ?? 0));
      } catch (e: any) {
        if (!alive) return;
        setRows([]);
        setTotal(0);
        setLoadErr(e?.message ?? "Greška pri dohvaćanju artikala.");
      } finally {
        if (!alive) return;
        setLoading(false);
      }
    })();
    return () => {
      alive = false;
    };
  }, [warehouseId, page, debouncedQ]);

  const totalPages = Math.max(1, Math.ceil((total || 0) / PAGE_SIZE));
  const canPrev = page > 0;
  const canNext = page + 1 < totalPages;

  const apply = () => {
    patchDraft(sessionId, partnerId, { standaloneQty: qtyDraft });
    router.back();
  };

  if (!draft) {
    return (
      <Screen style={{ backgroundColor: Colors.bg }} edges={["left", "right"]}>
        <TemplatesHeader
          title="Stavke"
          fallbackHref={{ pathname: "/(tabs)/sessions/[id]/entry" as const, params: { id: String(sessionId), partnerId: String(partnerId) } }}
        />
        <View style={{ padding: 16, alignItems: "center", gap: 10 }}>
          <ActivityIndicator />
          <Text style={{ color: Colors.sub, fontWeight: "800" }}>Učitavam…</Text>
        </View>
      </Screen>
    );
  }

  return (
    <Screen style={{ backgroundColor: Colors.bg }} edges={["left", "right"]}>
      <TemplatesHeader
        title="Dodatne stavke"
        subtitle={`Partner #${partnerId}`}
        fallbackHref={{ pathname: "/(tabs)/sessions/[id]/entry" as const, params: { id: String(sessionId), partnerId: String(partnerId) } }}
      />

      <View style={s.wrap}>
        {!!err && <Banner type="error" text={String(err)} />}

        {!warehouseId ? (
          <Banner type="error" text="Nema warehouseId na evidenciji." />
        ) : (
          <>
            <View style={s.tabs}>
              <Pressable style={[s.tabBtn, tab === "results" && s.tabBtnActive]} onPress={() => setTab("results")}>
                <Text style={[s.tabText, tab === "results" && s.tabTextActive]}>Rezultati</Text>
              </Pressable>
              <Pressable style={[s.tabBtn, tab === "added" && s.tabBtnActive]} onPress={() => setTab("added")}>
                <Text style={[s.tabText, tab === "added" && s.tabTextActive]}>Dodano ({qtyToItems(qtyDraft).length})</Text>
              </Pressable>
            </View>

            {tab === "results" ? (
              <>
                <View style={s.searchWrap}>
                  <FontAwesome name="search" size={14} color={Colors.sub} />
                  <TextInput
                    value={searchQ}
                    onChangeText={setSearchQ}
                    placeholder="Pretraži artikle (naziv, šifra)…"
                    placeholderTextColor={PLACEHOLDER}
                    style={s.search}
                    autoCorrect={false}
                    autoCapitalize="none"
                  />
                  {!!searchQ && (
                    <Pressable onPress={() => setSearchQ("")} hitSlop={8}>
                      <FontAwesome name="times-circle" size={16} color={Colors.sub} />
                    </Pressable>
                  )}
                </View>

                {!!loadErr && <Banner type="error" text={loadErr} />}

                {loading ? (
                  <View style={{ paddingVertical: 14, alignItems: "center" }}>
                    <ActivityIndicator />
                  </View>
                ) : (
                  <FlatList
                    data={rows}
                    keyExtractor={(it) => String((it as any).itemId)}
                    contentContainerStyle={{ gap: 10, paddingBottom: 10 }}
                    ListEmptyComponent={<Text style={s.helper}>Nema rezultata.</Text>}
                    renderItem={({ item }) => (
                      <View style={s.resultRow}>
                        <View style={{ flex: 1 }}>
                          <Text style={s.itemNameStrong} numberOfLines={2}>
                            {(item as any).name}
                          </Text>
                          <Text style={s.itemMeta} numberOfLines={1}>
                            {[
                              (item as any).code ? `Šifra: ${(item as any).code}` : null,
                              (item as any).unit ? `JMJ: ${(item as any).unit}` : null,
                            ]
                              .filter(Boolean)
                              .join(" • ")}
                          </Text>
                        </View>

                        <Pressable
                          style={s.addBtn}
                          onPress={() => {
                            const id = Number((item as any).itemId);
                            setQtyDraft((cur) => upsertQty(cur, id, 1));
                            setTab("added");
                          }}
                        >
                          <Text style={s.addBtnText}>+1</Text>
                        </Pressable>
                      </View>
                    )}
                  />
                )}

                <View style={s.pager}>
                  <Pressable style={[s.pagerBtn, !canPrev && { opacity: 0.4 }]} disabled={!canPrev} onPress={() => setPage((p) => Math.max(0, p - 1))}>
                    <FontAwesome name="chevron-left" size={14} color={Colors.text} />
                  </Pressable>

                  <Text style={s.pagerText}>
                    Str. {page + 1} / {totalPages}
                  </Text>

                  <Pressable style={[s.pagerBtn, !canNext && { opacity: 0.4 }]} disabled={!canNext} onPress={() => setPage((p) => p + 1)}>
                    <FontAwesome name="chevron-right" size={14} color={Colors.text} />
                  </Pressable>
                </View>
              </>
            ) : (
              <View style={{ gap: 10 }}>
                {qtyToItems(qtyDraft).length === 0 ? (
                  <Text style={s.helper}>Još nema dodanih stavki. Dodaj iz “Rezultati”.</Text>
                ) : (
                  <View style={{ gap: 10 }}>
                    {qtyToItems(qtyDraft).map((x) => (
                      <View key={String(x.itemId)} style={s.addedRow}>
                        <View style={{ flex: 1 }}>
                          <Text style={s.itemNameStrong}>Item #{x.itemId}</Text>
                          <Text style={s.itemMeta}>Količina: {Number(x.quantity ?? 0)}</Text>
                        </View>

                        <View style={s.qtyBox}>
                          <Pressable style={s.qtyBtn} onPress={() => setQtyDraft((cur) => upsertQty(cur, Number(x.itemId), -1))}>
                            <Text style={s.qtyBtnText}>−</Text>
                          </Pressable>

                          <View style={s.qtyPill}>
                            <Text style={s.qtyPillText}>{Number(x.quantity ?? 0)}</Text>
                          </View>

                          <Pressable style={s.qtyBtn} onPress={() => setQtyDraft((cur) => upsertQty(cur, Number(x.itemId), +1))}>
                            <Text style={s.qtyBtnText}>+</Text>
                          </Pressable>
                        </View>

                        <Pressable
                          style={s.smallDangerBtn}
                          onPress={() =>
                            setQtyDraft((cur) => {
                              const k = String(x.itemId);
                              const { [k]: _, ...rest } = cur;
                              return rest;
                            })
                          }
                        >
                          <Text style={s.smallDangerText}>X</Text>
                        </Pressable>
                      </View>
                    ))}
                  </View>
                )}
              </View>
            )}

            <Pressable style={s.primary} onPress={apply}>
              <Text style={s.primaryText}>Primijeni</Text>
            </Pressable>

            <Pressable style={s.btnWide} onPress={() => router.back()}>
              <Text style={s.btnText}>Zatvori</Text>
            </Pressable>
          </>
        )}
      </View>
    </Screen>
  );
}

const s = StyleSheet.create({
  wrap: { padding: 14, gap: 12, alignSelf: "center", width: "100%", maxWidth: MAX_W },

  helper: { color: Colors.sub, fontWeight: "800", textAlign: "center" },

  primary: { padding: 12, borderRadius: 14, backgroundColor: Colors.orange, alignItems: "center" },
  primaryText: { color: "#fff", fontWeight: "900" },

  btnWide: {
    width: "100%",
    padding: 12,
    borderRadius: 14,
    backgroundColor: "rgba(148,163,184,0.18)",
    alignItems: "center",
    justifyContent: "center",
  },
  btnText: { fontWeight: "900", color: Colors.text },

  tabs: { width: "100%", flexDirection: "row", gap: 10 },
  tabBtn: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 14,
    backgroundColor: "rgba(148,163,184,0.18)",
    alignItems: "center",
    justifyContent: "center",
  },
  tabBtnActive: {
    backgroundColor: "rgba(249,115,22,0.18)",
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "rgba(249,115,22,0.35)",
  },
  tabText: { fontWeight: "900", color: Colors.sub },
  tabTextActive: { color: Colors.text },

  searchWrap: {
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 14,
    backgroundColor: "rgba(148,163,184,0.14)",
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.border,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  search: { flex: 1, fontWeight: "800", color: Colors.text },

  resultRow: {
    width: "100%",
    borderRadius: 14,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.border,
    backgroundColor: Colors.bg,
    padding: 12,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },

  itemNameStrong: { fontWeight: "900", color: Colors.text, fontSize: 15 },
  itemMeta: { color: Colors.sub, fontWeight: "800" },

  addBtn: {
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 12,
    backgroundColor: "rgba(249,115,22,0.16)",
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "rgba(249,115,22,0.35)",
    alignItems: "center",
    justifyContent: "center",
  },
  addBtnText: { fontWeight: "900", color: Colors.text },

  pager: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 10, marginTop: 6 },
  pagerBtn: {
    width: 38,
    height: 38,
    borderRadius: 14,
    backgroundColor: "rgba(148,163,184,0.18)",
    alignItems: "center",
    justifyContent: "center",
  },
  pagerText: { fontWeight: "900", color: Colors.sub },

  addedRow: {
    width: "100%",
    borderRadius: 14,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.border,
    backgroundColor: Colors.bg,
    padding: 12,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },

  qtyBox: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    backgroundColor: "rgba(148,163,184,0.12)",
    borderRadius: 14,
    padding: 6,
  },
  qtyBtn: {
    width: 34,
    height: 34,
    borderRadius: 12,
    backgroundColor: "rgba(148,163,184,0.18)",
    alignItems: "center",
    justifyContent: "center",
  },
  qtyBtnText: { fontWeight: "900", color: Colors.text, fontSize: 18 },

  qtyPill: {
    minWidth: 52,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 12,
    backgroundColor: "rgba(148,163,184,0.10)",
    alignItems: "center",
    justifyContent: "center",
  },
  qtyPillText: { fontWeight: "900", color: Colors.text },

  smallDangerBtn: {
    width: 34,
    height: 34,
    borderRadius: 12,
    backgroundColor: Colors.dangerBg,
    alignItems: "center",
    justifyContent: "center",
  },
  smallDangerText: { fontWeight: "900", color: Colors.dangerText },
});
