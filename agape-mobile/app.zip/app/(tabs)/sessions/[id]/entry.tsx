import React, { useEffect, useMemo, useRef, useState } from "react";
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from "react-native";
import FontAwesome from "@expo/vector-icons/FontAwesome";
import { useLocalSearchParams, router } from "expo-router";

import Screen from "@/components/ui/Screen";
import Colors from "@/constants/Colors";
import { Banner } from "@/components/Banner";
import TemplatesHeader from "@/app/(tabs)/templates/TemplatesHeader";

import type {
  BookingSessionEntryResponseDTO,
  BookingSessionEntryUpsertRequestDTO,
  BookingSessionResponseDTO,
  DraftMode,
  ItemDescriptorResponseDTO,
  TemplateBookDocPatchDTO,
  TemplateBookItemDTO,
  TemplateDocResponseDTO,
  TemplateItemResponseDTO,
  TemplateResponseDTO,
} from "@/app/models/generated";

import { dispatchTemplateService } from "@/app/api/services/dispatchTemplateService";
import { partnerService } from "@/app/api/services/partnerService";
import { useBookingSession, useUpsertBookingSessionEntry } from "@/app/api/hooks/useBookingSessions";

import { QtyMap, useEntryDraft, getDraft, setDraft, clearDraft, patchDraft } from "../_entryDraftStore";

const MAX_W = 560;

function cleanText(v: any) {
  const s = String(v ?? "").trim();
  if (s.length >= 2 && ((s.startsWith('"') && s.endsWith('"')) || (s.startsWith("'") && s.endsWith("'")))) return s.slice(1, -1);
  return s;
}

function qtyToItems(qty: QtyMap): TemplateBookItemDTO[] {
  return Object.entries(qty ?? {})
    .map(([k, v]) => ({ itemId: Number(k), quantity: Number(v) }))
    .filter((x) => x.itemId && x.quantity > 0)
    .sort((a, b) => Number(a.itemId) - Number(b.itemId));
}

function mkPatch(docId: number, addItems: TemplateBookItemDTO[]): TemplateBookDocPatchDTO {
  return {
    documentId: docId,
    addItems,
    setItems: [],
    removeItemIds: [],
    draftOverride: null as any,
    noteOverride: null as any,
  } as any;
}

async function fetchItemDescriptorsByIds(args: {
  warehouseId: number;
  itemIds: number[];
}): Promise<ItemDescriptorResponseDTO[]> {
  const { warehouseId, itemIds } = args;
  const uniq = Array.from(new Set(itemIds)).filter((x) => Number(x) > 0);
  if (!uniq.length) return [];

  const res = await fetch(`/api/item-directory/descriptors`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ warehouseId, itemIds: uniq }),
  });

  if (!res.ok) throw new Error(`Failed to load item descriptors (${res.status})`);
  return (await res.json()) as ItemDescriptorResponseDTO[];
}

function upsertMetaMap(prev: Map<number, ItemDescriptorResponseDTO>, items: ItemDescriptorResponseDTO[] | null | undefined) {
  const next = new Map(prev);
  (items ?? []).forEach((it) => {
    const id = Number((it as any)?.itemId ?? (it as any)?.id);
    if (!id) return;
    next.set(id, it);
  });
  return next;
}

function itemName(itemId: number, metaById: Map<number, ItemDescriptorResponseDTO>) {
  return metaById.get(Number(itemId))?.name?.trim() ?? "";
}

function itemMeta(itemId: number, metaById: Map<number, ItemDescriptorResponseDTO>) {
  const m = metaById.get(Number(itemId));
  if (!m) return "";
  const parts = [
    (m as any)?.code ? `Šifra: ${(m as any).code}` : null,
    (m as any)?.unit ? `JMJ: ${(m as any).unit}` : null,
    (m as any)?.barcode ? `BC: ${(m as any).barcode}` : null,
  ].filter(Boolean);
  return parts.join(" • ");
}

export default function SessionEntryEditor() {
  const params = useLocalSearchParams<{ id: string; partnerId: string }>();
  const sessionId = Number(params.id);
  const partnerId = Number(params.partnerId);

  const sQ = useBookingSession(sessionId);
  const session = sQ.data as BookingSessionResponseDTO | undefined;
  const warehouseId = Number((session as any)?.warehouseId ?? 0) || null;

  const upsertM = useUpsertBookingSessionEntry(sessionId);

  const draft = useEntryDraft(sessionId, partnerId);
  const [selectedTemplate, setSelectedTemplate] = useState<TemplateResponseDTO | null>(null);

  // partner name for nicer header
  const [partnerName, setPartnerName] = useState<string>("");

  useEffect(() => {
    let alive = true;

    (async () => {
      try {
        const hitFromSession =
          ((session as any)?.entries ?? []).find((e: any) => Number(e.partnerId) === Number(partnerId)) ?? null;

        const maybeName =
          cleanText((hitFromSession as any)?.partnerName) ||
          cleanText((hitFromSession as any)?.partner?.name) ||
          "";

        if (maybeName) {
          if (!alive) return;
          setPartnerName(maybeName);
          return;
        }

        // fallback: try by searching partners (best-effort)
        const res = await partnerService.pagePartners({ page: 0, size: 20, q: String(partnerId) });
        const hit = (res.items ?? []).find((p: any) => Number(p.id) === Number(partnerId)) ?? null;

        if (!alive) return;
        setPartnerName(cleanText((hit as any)?.name) || "");
      } catch {
        if (!alive) return;
        setPartnerName("");
      }
    })();

    return () => {
      alive = false;
    };
  }, [partnerId, session?.id, (session as any)?.entries?.length]);

  const headerTitle = partnerName?.trim()
    ? `Unos • ${partnerName}`
    : `Unos • Partner #${partnerId}`;

  // init draft from session entry (once)
  useEffect(() => {
    if (!session) return;

    const existing = ((session as any).entries ?? []).find(
      (e: any) => Number(e.partnerId) === partnerId
    ) as BookingSessionEntryResponseDTO | undefined;

    const cur = getDraft(sessionId, partnerId);
    if (cur) return;

    const init = {
      sessionId,
      partnerId,
      draftMode: ((existing as any)?.draftMode ?? "DRAFT") as any,
      templateId: Number((existing as any)?.templateId ?? 0) || null,
      docPatches: Array.isArray((existing as any)?.docPatches) ? (existing as any).docPatches : [],
      standaloneQty: (existing as any)?.standaloneQty ?? {}, // not from backend usually; keep empty
      note: (existing as any)?.note ?? null,
      documentDate: (existing as any)?.documentDate ?? null,
    };

    setDraft(init as any);
  }, [session?.id, partnerId]);

  // load selected template by id (full)
  useEffect(() => {
    let alive = true;

    (async () => {
      const tplId = Number(draft?.templateId ?? 0);
      if (!tplId) {
        setSelectedTemplate(null);
        return;
      }
      try {
        const full = await dispatchTemplateService.getTemplate(tplId);
        if (!alive) return;
        setSelectedTemplate(full as any);
      } catch {
        if (!alive) return;
        setSelectedTemplate(null);
      }
    })();

    return () => {
      alive = false;
    };
  }, [draft?.templateId]);

  const templateDocs: TemplateDocResponseDTO[] = useMemo(
    () => (((selectedTemplate as any)?.documents ?? []) as any[]),
    [selectedTemplate]
  );

  const defaultDocId = useMemo(() => {
    const first = templateDocs?.[0] as any;
    const id = Number(first?.documentId ?? first?.document_id ?? 0);
    return id || null;
  }, [templateDocs]);

  // build "default rows" like in otpremi.tsx
  const defaultRowsByDoc = useMemo(() => {
    return (templateDocs ?? [])
      .map((d: any) => {
        const docId = Number(d?.documentId ?? d?.document_id ?? 0);
        const rows = (((d?.items ?? []) as any[]) as TemplateItemResponseDTO[])
          .map((x: any) => ({
            itemId: Number(x?.itemId),
            quantity: Number(x?.quantity ?? 0),
          }))
          .filter((x) => x.itemId && x.quantity > 0)
          .sort((a, b) => a.itemId - b.itemId);

        return { docId, rows, count: rows.length };
      })
      .filter((x) => x.docId);
  }, [templateDocs]);

  // standalone items (van dokumenta)
  const standaloneItems = useMemo(() => qtyToItems(draft?.standaloneQty ?? {}), [draft?.standaloneQty]);

  // meta preload (names)
  const requiredItemIds = useMemo(() => {
    const ids: number[] = [];

    for (const d of templateDocs ?? []) {
      for (const it of (((d as any)?.items ?? []) as any[])) {
        const id = Number((it as any)?.itemId);
        if (id) ids.push(id);
      }
    }

    for (const it of standaloneItems ?? []) {
      const id = Number((it as any)?.itemId);
      if (id) ids.push(id);
    }

    return Array.from(new Set(ids)).sort((a, b) => a - b);
  }, [templateDocs, standaloneItems]);

  const [metaById, setMetaById] = useState<Map<number, ItemDescriptorResponseDTO>>(new Map());
  const [namesLoading, setNamesLoading] = useState(false);
  const preloadKeyRef = useRef<string>("");

  useEffect(() => {
    if (!warehouseId) return;
    if (!requiredItemIds.length) return;

    const missing = requiredItemIds.filter((id) => !metaById.get(id)?.name?.trim());
    const key = `${warehouseId}:${missing.join(",")}`;

    if (!missing.length) {
      setNamesLoading(false);
      preloadKeyRef.current = "";
      return;
    }
    if (preloadKeyRef.current === key) return;

    preloadKeyRef.current = key;
    setNamesLoading(true);

    (async () => {
      try {
        const list = await fetchItemDescriptorsByIds({ warehouseId: Number(warehouseId), itemIds: missing });
        setMetaById((prev) => upsertMetaMap(prev, list));
      } catch {
        // silent
      } finally {
        setNamesLoading(false);
      }
    })();
  }, [warehouseId, requiredItemIds, metaById]);

  const namesReady = useMemo(() => {
    if (!requiredItemIds.length) return true;
    for (const id of requiredItemIds) if (!metaById.get(id)?.name?.trim()) return false;
    return true;
  }, [requiredItemIds, metaById]);

  const err = (sQ.error as any)?.message || (upsertM.error as any)?.message || null;

  const openTemplatePicker = () => {
    router.push({
      pathname: "/(tabs)/sessions/[id]/template" as const,
      params: { id: String(sessionId), partnerId: String(partnerId) },
    });
  };

  const openStandaloneItems = () => {
    router.push({
      pathname: "/(tabs)/sessions/[id]/items" as const,
      params: { id: String(sessionId), partnerId: String(partnerId) },
    });
  };

  const save = async () => {
    if (!session || (session as any).status !== "DRAFT") return;
    if (!draft) return;

    const tplId = Number(draft.templateId ?? 0);
    if (!tplId) return;

    let docPatches: TemplateBookDocPatchDTO[] = [...((draft as any).docPatches ?? [])];

    // merge standaloneQty into FIRST template doc (same behavior as otpremi hint)
    const standalone = qtyToItems(draft.standaloneQty ?? {});
    if (standalone.length && defaultDocId) {
      const idx = docPatches.findIndex((p: any) => Number((p as any).documentId) === Number(defaultDocId));

      if (idx === -1) {
        docPatches.push(mkPatch(defaultDocId, standalone));
      } else {
        const cur = Array.isArray((docPatches[idx] as any)?.addItems) ? (docPatches[idx] as any).addItems : [];
        const by = new Map<number, number>();

        [...cur, ...standalone].forEach((x: any) => {
          const id = Number(x.itemId);
          const q = Number(x.quantity ?? 0);
          if (!id || q <= 0) return;
          by.set(id, (by.get(id) ?? 0) + q);
        });

        (docPatches[idx] as any) = {
          ...(docPatches[idx] as any),
          addItems: Array.from(by.entries()).map(([itemId, quantity]) => ({ itemId, quantity })),
        };
      }
    }

    const payload: BookingSessionEntryUpsertRequestDTO = {
      partnerId: Number(draft.partnerId),
      templateId: tplId,
      draftMode: (draft.draftMode ?? "DRAFT") as any,
      documentDate: (draft as any).documentDate ?? null,
      docPatches: docPatches as any,

      // depending on backend DTO naming, keep both as any to be safe
      extraItems: [] as any,
      extraDocuments: [] as any,

      note: (draft as any).note ?? null,
    } as any;

    await upsertM.mutateAsync(payload);
    clearDraft(sessionId, partnerId);
    await sQ.refetch();
    router.back();
  };

  if (!draft) {
    return (
      <Screen style={{ backgroundColor: Colors.bg }} edges={["left", "right"]}>
        <TemplatesHeader
          title="Unos"
          fallbackHref={{ pathname: "/(tabs)/sessions/[id]" as const, params: { id: String(sessionId) } }}
        />
        <View style={{ padding: 16, alignItems: "center", gap: 10 }}>
          <ActivityIndicator />
          <Text style={{ color: Colors.sub, fontWeight: "800" }}>Učitavam…</Text>
        </View>
      </Screen>
    );
  }

  return (
    <Screen style={{ backgroundColor: Colors.bg }} edges={["left", "right"]}>
      <TemplatesHeader
        title={headerTitle}
        fallbackHref={{ pathname: "/(tabs)/sessions/[id]" as const, params: { id: String(sessionId) } }}
      />

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={st.container}
        keyboardShouldPersistTaps="handled"
      >
        {!!err && <Banner type="error" text={String(err)} />}

        <Text style={st.label}>Način</Text>
        <View style={st.segmentRow}>
          <Pressable
            style={[st.segBtn, draft.draftMode === "DRAFT" && st.segBtnOn]}
            onPress={() => patchDraft(sessionId, partnerId, { draftMode: "DRAFT" })}
          >
            <Text style={[st.segText, draft.draftMode === "DRAFT" && st.segTextOn]}>Draft</Text>
          </Pressable>

          <Pressable
            style={[st.segBtn, draft.draftMode === "FINAL" && st.segBtnOn]}
            onPress={() => patchDraft(sessionId, partnerId, { draftMode: "FINAL" })}
          >
            <Text style={[st.segText, draft.draftMode === "FINAL" && st.segTextOn]}>Final</Text>
          </Pressable>
        </View>

        <View style={st.sectionHeader}>
          <Text style={st.label}>Predložak</Text>
          <Pressable style={st.smallBtn} onPress={openTemplatePicker}>
            <Text style={st.smallBtnText}>{draft.templateId ? "Promijeni" : "Odaberi"}</Text>
          </Pressable>
        </View>

        {selectedTemplate ? (
          <View style={[st.pickRow, st.pickRowSelected]}>
            <View style={{ flex: 1 }}>
              <Text style={st.pickTitle}>{(selectedTemplate as any).name}</Text>
              <Text style={st.pickSub}>
                #{(selectedTemplate as any).id} • dokumenata: {(selectedTemplate as any).documents?.length ?? 0}
              </Text>
            </View>

            <Pressable
              style={st.iconBtn}
              onPress={() => {
                patchDraft(sessionId, partnerId, { templateId: null, docPatches: [], standaloneQty: {} });
                setSelectedTemplate(null);
              }}
            >
              <FontAwesome name="trash" size={16} color={Colors.text} />
            </Pressable>
          </View>
        ) : (
          <Text style={st.helper}>Nije odabran predložak.</Text>
        )}

        {/* ------------------ DOCUMENTS (DEFAULT) ------------------ */}
        {selectedTemplate ? (
          <>
            <Text style={st.label}>Dokumenti (default iz predloška)</Text>

            {!namesReady ? (
              <View style={st.loadingBox}>
                <ActivityIndicator />
                <Text style={st.helper}>Učitavam nazive stavki…</Text>
              </View>
            ) : defaultRowsByDoc.length === 0 ? (
              <Text style={st.helper}>Predložak nema dokumenata / stavki.</Text>
            ) : (
              <View style={{ gap: 10 }}>
                {defaultRowsByDoc.map((block) => (
                  <View key={String(block.docId)} style={st.cardCol}>
                    <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", gap: 10 }}>
                      <View style={{ flex: 1 }}>
                        <Text style={st.title}>Dokument #{block.docId}</Text>
                        <Text style={st.sub}>Default stavki: {block.count}</Text>
                      </View>

                      {defaultDocId && block.docId === defaultDocId ? (
                        <View style={st.pill}>
                          <Text style={st.pillText}>DEFAULT</Text>
                        </View>
                      ) : null}
                    </View>

                    {block.count === 0 ? (
                      <Text style={st.muted}>Nema stavki.</Text>
                    ) : (
                      <View style={{ gap: 8, marginTop: 10 }}>
                        {block.rows.map((r) => {
                          const nm = itemName(r.itemId, metaById);
                          const meta = itemMeta(r.itemId, metaById);

                          return (
                            <View key={String(r.itemId)} style={st.simpleRow}>
                              <View style={{ flex: 1 }}>
                                <Text style={st.itemNameStrong} numberOfLines={2}>
                                  {nm || `Item #${r.itemId}`}
                                </Text>
                                {!!meta && (
                                  <Text style={st.itemMeta} numberOfLines={1}>
                                    {meta}
                                  </Text>
                                )}
                              </View>
                              <Text style={st.simpleRight}>x{r.quantity}</Text>
                            </View>
                          );
                        })}
                      </View>
                    )}
                  </View>
                ))}
              </View>
            )}
          </>
        ) : null}

        {/* ------------------ STANDALONE ITEMS ------------------ */}
        <View style={st.sectionHeader}>
          <Text style={st.label}>Dodatne stavke (van dokumenta)</Text>
          <Pressable style={st.smallBtn} onPress={openStandaloneItems} disabled={!draft.templateId}>
            <Text style={st.smallBtnText}>{standaloneItems.length ? `Uredi (${standaloneItems.length})` : "+ Dodaj"}</Text>
          </Pressable>
        </View>

        {!draft.templateId ? (
          <Text style={st.helper}>Prvo odaberi predložak pa dodaj stavke.</Text>
        ) : !defaultDocId ? (
          <Text style={st.helper}>Predložak nema dokumenata – ne mogu primijeniti dodatne stavke.</Text>
        ) : (
          <View style={st.cardCol}>
            <Text style={st.title}>Dodano van dokumenta</Text>
            <Text style={st.sub}>
              Stavki: {standaloneItems.length} • Primjenjuje se na dokument #{defaultDocId}
            </Text>

            {standaloneItems.length === 0 ? (
              <Text style={st.muted}>Nema dodanih stavki.</Text>
            ) : !namesReady ? (
              <View style={{ paddingVertical: 10, alignItems: "center" }}>
                <ActivityIndicator />
              </View>
            ) : (
              <View style={{ gap: 8, marginTop: 10 }}>
                {standaloneItems.map((r) => {
                  const nm = itemName(Number(r.itemId), metaById);
                  const meta = itemMeta(Number(r.itemId), metaById);

                  return (
                    <View key={String(r.itemId)} style={st.simpleRow}>
                      <View style={{ flex: 1 }}>
                        <Text style={st.itemNameStrong} numberOfLines={2}>
                          {nm || `Item #${r.itemId}`}
                        </Text>
                        {!!meta && (
                          <Text style={st.itemMeta} numberOfLines={1}>
                            {meta}
                          </Text>
                        )}
                      </View>
                      <Text style={st.simpleRight}>x{Number(r.quantity ?? 0)}</Text>
                    </View>
                  );
                })}
              </View>
            )}

            <Text style={[st.helper, { marginTop: 10 }]}>
              Ove stavke nisu vezane uz određeni dokument. Aplikacija će ih primijeniti na default dokument predloška.
            </Text>
          </View>
        )}

        {/* ------------------ ACTIONS ------------------ */}
        <Pressable
          style={[st.primaryBtn, (!draft.templateId || upsertM.isPending || namesLoading) && { opacity: 0.5 }]}
          disabled={!draft.templateId || upsertM.isPending || namesLoading}
          onPress={save}
        >
          {upsertM.isPending ? <ActivityIndicator /> : <Text style={st.primaryText}>Spremi</Text>}
        </Pressable>

        <Pressable
          style={[st.ghostBtn, upsertM.isPending && { opacity: 0.6 }]}
          disabled={upsertM.isPending}
          onPress={() => {
            if (upsertM.isPending) return;
            clearDraft(sessionId, partnerId);
            router.back();
          }}
        >
          <Text style={st.ghostText}>Zatvori</Text>
        </Pressable>
      </ScrollView>
    </Screen>
  );
}

const st = StyleSheet.create({
  container: { padding: 14, gap: 12, alignSelf: "center", width: "100%", maxWidth: MAX_W },

  helper: { color: Colors.sub, fontWeight: "800" },
  label: { fontWeight: "900", color: Colors.text },

  sectionHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between" },

  primaryBtn: {
    paddingVertical: 12,
    borderRadius: 14,
    backgroundColor: Colors.orange,
    alignItems: "center",
    justifyContent: "center",
    marginTop: 2,
  },
  primaryText: { color: "#fff", fontWeight: "900" },

  ghostBtn: {
    paddingVertical: 12,
    borderRadius: 14,
    backgroundColor: "rgba(148,163,184,0.20)",
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "rgba(2, 6, 23, 0.10)",
    alignItems: "center",
    justifyContent: "center",
  },
  ghostText: { fontWeight: "900", color: Colors.text },

  smallBtn: {
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 14,
    backgroundColor: "rgba(249,115,22,0.12)",
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "rgba(249,115,22,0.35)",
    alignItems: "center",
    justifyContent: "center",
  },
  smallBtnText: { fontWeight: "900", color: Colors.text },

  pickRow: {
    padding: 12,
    borderRadius: 16,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.border,
    backgroundColor: Colors.bg,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  pickRowSelected: { borderColor: Colors.orange, backgroundColor: "rgba(249,115,22,0.10)" },
  pickTitle: { fontWeight: "900", color: Colors.text },
  pickSub: { color: Colors.sub, fontWeight: "800" },

  iconBtn: {
    width: 40,
    height: 40,
    borderRadius: 14,
    backgroundColor: "rgba(148,163,184,0.18)",
    alignItems: "center",
    justifyContent: "center",
  },

  loadingBox: {
    width: "100%",
    borderRadius: 18,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.border,
    backgroundColor: Colors.bg,
    padding: 16,
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
  },

  cardCol: {
    backgroundColor: Colors.bg,
    borderRadius: 18,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.border,
    padding: 14,
    gap: 10,
  },

  title: { fontWeight: "900", color: Colors.text, fontSize: 15 },
  sub: { color: Colors.sub, fontWeight: "800" },
  muted: { color: Colors.sub, fontWeight: "700" },

  pill: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: "rgba(34,197,94,0.15)",
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: "rgba(34,197,94,0.35)",
  },
  pillText: { fontWeight: "900", color: Colors.text },

  simpleRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 12,
    paddingVertical: 10,
    paddingHorizontal: 10,
    borderRadius: 14,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.border,
    backgroundColor: "rgba(148,163,184,0.10)",
    alignItems: "center",
  },
  simpleRight: { fontWeight: "900", color: Colors.sub },

  itemNameStrong: { fontWeight: "900", color: Colors.text, fontSize: 15 },
  itemMeta: { color: Colors.sub, fontWeight: "800" },

  segmentRow: { flexDirection: "row", gap: 10 },
  segBtn: {
    flex: 1,
    paddingVertical: 10,
    borderRadius: 14,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.border,
    backgroundColor: "rgba(148,163,184,0.12)",
    alignItems: "center",
    justifyContent: "center",
  },
  segBtnOn: { backgroundColor: "rgba(249,115,22,0.12)", borderColor: "rgba(249,115,22,0.35)" },
  segText: { fontWeight: "900", color: Colors.sub },
  segTextOn: { color: Colors.text },
});
