// app/(tabs)/dispatch-bookings/index.tsx
import React, { useEffect, useMemo, useState } from "react";
import { ActivityIndicator, FlatList, Pressable, StyleSheet, Text, TextInput, View } from "react-native";
import FontAwesome from "@expo/vector-icons/FontAwesome";
import { router } from "expo-router";

import Colors from "@/constants/Colors";
import Screen from "@/components/ui/Screen"; // adjust if your path differs
import { Banner } from "@/components/Banner"; // adjust if needed

import type { DispatchResponseDTO, DocumentDescriptorResponseDTO } from "@/app/models/generated";
import { SearchPickerSheet } from "@/components/SearchPickerSheet"; // adjust import path
import { useDispatchBookingsInfinite } from "@/app/api/hooks/useDispatchBookings";
import { SegPills } from "@/components/SegPills";

// NOTE: replace this with your real fetcher you already have for document slots/types
// You said you already have it; keep signature same as SearchPickerSheet expects.
type PageResult<T> = { items: T[]; page: number; size: number; total: number };
async function fetchDocTypesPage(_args: { page: number; size: number; q?: string }): Promise<PageResult<DocumentDescriptorResponseDTO>> {
  // TODO: plug your real endpoint
  return { items: [], page: 0, size: 20, total: 0 };
}

function fmtDate(d: any) {
  if (!d) return "";
  try {
    if (d instanceof Date) return d.toISOString().slice(0, 10);
    const s = String(d);
    return s.length >= 10 ? s.slice(0, 10) : s;
  } catch {
    return "";
  }
}

type StatusFilter = "ALL" | "DRAFT" | "FINAL";
type SortFilter = "BOOKED_DESC" | "BOOKED_ASC";

export default function DispatchBookingsIndex() {
  // You likely already have warehouseId in global state / current session.
  // For now: keep as state or replace with your existing hook.
  const warehouseId = 1;

  const [q, setQ] = useState("");
  const [debouncedQ, setDebouncedQ] = useState("");

  const [status, setStatus] = useState<StatusFilter>("ALL");
  const [sort, setSort] = useState<SortFilter>("BOOKED_DESC");

  const [dateFrom, setDateFrom] = useState<string>("");
  const [dateTo, setDateTo] = useState<string>("");

  // default doc = OTPREMNICA
  const [documentCode, setDocumentCode] = useState<string>("OTPREMNICA");
  const [docPickerOpen, setDocPickerOpen] = useState(false);

  // debounce search
  useEffect(() => {
    const t = setTimeout(() => setDebouncedQ(q.trim()), 250);
    return () => clearTimeout(t);
  }, [q]);

  const base = useMemo(
    () => ({
      warehouseId,
      size: 20,
      q: debouncedQ || undefined,
      documentCode: documentCode || undefined,
      status,
      dateFrom: dateFrom || undefined,
      dateTo: dateTo || undefined,
      sort,
    }),
    [warehouseId, debouncedQ, documentCode, status, dateFrom, dateTo, sort]
  );

  const listQ = useDispatchBookingsInfinite(base as any);

  const flatItems: DispatchResponseDTO[] = useMemo(() => {
    const pages = listQ.data?.pages ?? [];
    return pages.flatMap((p: any) => (p?.items ?? []) as DispatchResponseDTO[]);
  }, [listQ.data]);

  const total = listQ.data?.pages?.[0]?.total ?? 0;

  const errorMsg = (listQ.error as any)?.message ?? null;

  return (
    <Screen>
      <View style={s.wrap}>
        {!!errorMsg && <Banner type="error" text={errorMsg} />}

        {/* Top controls */}
        <View style={s.card}>
          <View style={s.searchWrap}>
            <FontAwesome name="search" size={14} color={Colors.sub} />
            <TextInput
              value={q}
              onChangeText={setQ}
              placeholder="Pretraži dokument (naziv/šifra)…"
              placeholderTextColor={Colors.sub}
              style={s.search}
              autoCorrect={false}
              autoCapitalize="none"
              returnKeyType="search"
            />
            {!!q && (
              <Pressable onPress={() => setQ("")} hitSlop={8}>
                <FontAwesome name="times-circle" size={16} color={Colors.sub} />
              </Pressable>
            )}
          </View>

          <View style={{ gap: 10 }}>
            {/* doc picker + sort */}
            <View style={{ flexDirection: "row", gap: 10, flexWrap: "wrap" }}>
              <Pressable style={s.pillBtn} onPress={() => setDocPickerOpen(true)}>
                <FontAwesome name="file-text-o" size={14} color={Colors.text} />
                <Text style={s.pillBtnText}>Dok: {documentCode || "—"}</Text>
              </Pressable>

              <Pressable
                style={s.pillBtn}
                onPress={() => setSort((v) => (v === "BOOKED_DESC" ? "BOOKED_ASC" : "BOOKED_DESC"))}
              >
                <FontAwesome name="sort" size={14} color={Colors.text} />
                <Text style={s.pillBtnText}>
                  {sort === "BOOKED_DESC" ? "Najnovije" : "Najstarije"}
                </Text>
              </Pressable>
            </View>

            {/* status */}
            <SegPills
              value={status}
              onChange={setStatus}
              options={[
                { key: "ALL", label: "Sve" },
                { key: "DRAFT", label: "Draft" },
                { key: "FINAL", label: "Final" },
              ]}
            />

            {/* dates */}
            <View style={{ flexDirection: "row", gap: 10 }}>
              <View style={{ flex: 1 }}>
                <Text style={s.smallLbl}>Datum od (YYYY-MM-DD)</Text>
                <TextInput
                  value={dateFrom}
                  onChangeText={setDateFrom}
                  placeholder="npr. 2026-02-01"
                  placeholderTextColor={Colors.sub}
                  style={s.input}
                  autoCorrect={false}
                  autoCapitalize="none"
                />
              </View>

              <View style={{ flex: 1 }}>
                <Text style={s.smallLbl}>Datum do (YYYY-MM-DD)</Text>
                <TextInput
                  value={dateTo}
                  onChangeText={setDateTo}
                  placeholder="npr. 2026-02-07"
                  placeholderTextColor={Colors.sub}
                  style={s.input}
                  autoCorrect={false}
                  autoCapitalize="none"
                />
              </View>
            </View>

            <Text style={s.hint}>
              Ukupno: {String(total)} • Prikazano: {String(flatItems.length)}
            </Text>
          </View>
        </View>

        {/* List */}
        {listQ.isLoading ? (
          <View style={s.center}>
            <ActivityIndicator />
            <Text style={s.muted}>Učitavam…</Text>
          </View>
        ) : (
          <FlatList
            data={flatItems}
            keyExtractor={(it) => String((it as any)?.id ?? (it as any)?.headerId ?? Math.random())}
            contentContainerStyle={{ paddingBottom: 24, gap: 10 }}
            onEndReachedThreshold={0.35}
            onEndReached={() => {
              if (listQ.hasNextPage && !listQ.isFetchingNextPage) listQ.fetchNextPage();
            }}
            renderItem={({ item }) => {
              const id = (item as any)?.id ?? (item as any)?.headerId;
              const docCode = String((item as any)?.documentCode ?? documentCode ?? "");
              const docNo = String((item as any)?.documentNumber ?? (item as any)?.documentBr ?? "");
              const bookedAt = (item as any)?.bookedAt ?? (item as any)?.createdAt ?? (item as any)?.dateBooked;

              const st = String((item as any)?.status ?? "");
              const isCancelled = st === "CANCELLED";

              return (
                <Pressable
                  style={[s.row, isCancelled && { opacity: 0.65 }]}
                  onPress={() => router.push(`/dispatch-bookings/${id}`)}
                >
                  <View style={{ flex: 1, gap: 2 }}>
                    <Text style={s.rowTitle} numberOfLines={1}>
                      {docCode} {docNo ? `• ${docNo}` : ""}
                    </Text>

                    <Text style={s.rowSub} numberOfLines={1}>
                      Datum: {fmtDate(bookedAt)} • Status: {st || "—"}
                    </Text>

                    {!!(item as any)?.partnerName && (
                      <Text style={s.rowSub} numberOfLines={1}>
                        Partner: {String((item as any)?.partnerName)}
                      </Text>
                    )}
                  </View>

                  <FontAwesome name="chevron-right" size={16} color={Colors.sub} />
                </Pressable>
              );
            }}
            ListEmptyComponent={<Text style={s.empty}>Nema rezultata.</Text>}
            ListFooterComponent={
              listQ.isFetchingNextPage ? (
                <View style={{ paddingVertical: 12 }}>
                  <ActivityIndicator />
                </View>
              ) : null
            }
          />
        )}

        {/* Document picker (uses your SearchPickerSheet) */}
        <SearchPickerSheet<DocumentDescriptorResponseDTO>
          visible={docPickerOpen}
          title="Odaberi dokument"
          onClose={() => setDocPickerOpen(false)}
          keyOf={(x) => String((x as any).documentId)}
          fetchPage={fetchDocTypesPage}
          renderRow={(d, close) => (
            <Pressable
              style={s.pickRow}
              onPress={() => {
                setDocumentCode(String((d as any).documentCode ?? "OTPREMNICA"));
                close();
              }}
            >
              <Text style={s.pickTitle}>{String((d as any).displayName ?? "")}</Text>
              <Text style={s.pickSub}>
                Šifra: {String((d as any).documentCode ?? "")} • ID: {String((d as any).documentId ?? "")}
              </Text>
            </Pressable>
          )}
        />
      </View>
    </Screen>
  );
}

const s = StyleSheet.create({
  wrap: { flex: 1, padding: 14, gap: 12 },

  card: {
    borderRadius: 16,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.border,
    backgroundColor: Colors.bg,
    padding: 12,
    gap: 10,
  },

  searchWrap: {
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 14,
    backgroundColor: "rgba(148,163,184,0.14)",
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.border,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  search: { flex: 1, fontWeight: "800", color: Colors.text },

  pillBtn: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 999,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.border,
    backgroundColor: "rgba(148,163,184,0.12)",
  },
  pillBtnText: { fontWeight: "900", color: Colors.text, fontSize: 12 },

  smallLbl: { color: Colors.sub, fontWeight: "900", fontSize: 11, marginBottom: 6 },
  input: {
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 14,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.border,
    backgroundColor: "rgba(148,163,184,0.10)",
    fontWeight: "900",
    color: Colors.text,
  },

  hint: { color: Colors.sub, fontWeight: "800", fontSize: 12 },

  row: {
    borderRadius: 16,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.border,
    backgroundColor: Colors.bg,
    padding: 12,
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  rowTitle: { fontWeight: "900", color: Colors.text, fontSize: 14 },
  rowSub: { fontWeight: "800", color: Colors.sub, fontSize: 12 },

  center: { padding: 20, alignItems: "center", gap: 10 },
  muted: { color: Colors.sub, fontWeight: "800" },
  empty: { textAlign: "center", color: Colors.sub, fontWeight: "800", paddingVertical: 18 },

  pickRow: {
    padding: 12,
    borderRadius: 16,
    borderWidth: StyleSheet.hairlineWidth,
    borderColor: Colors.border,
    backgroundColor: Colors.bg,
    gap: 4,
  },
  pickTitle: { fontWeight: "900", color: Colors.text, fontSize: 14 },
  pickSub: { fontWeight: "800", color: Colors.sub, fontSize: 12 },
});
